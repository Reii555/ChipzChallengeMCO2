public class ForceFloor extends Tile {
    private Direction forceDirection;

    /**
     * Constructs a new Force Floor tile.
     * This tile type automatically pushes the player in a specific direction
     * when they step onto it, acting as a conveyor belt or slippery slope.
     * @param position The grid coordinates where this tile is located.
     * @param forceDirection The cardinal direction (UP, DOWN, LEFT, RIGHT) this floor pushes the player towards.
     */
    public ForceFloor(Position position, Direction forceDirection){
        super(position);
        this.forceDirection = forceDirection;
    }

    /**
     * Determines if the player character is allowed to enter this tile.
     * Force floors are not obstacles and do not block movement, so this
     * always returns true.
     * @param c The instance of the player character (Chip).
     * @return true always, indicating the tile is passable.
     */
    @Override
    public boolean isPassable(Chip c) {
        return true; // Force floors are always passable
    }

    /**
     * Defines the specific behavior triggered when the player steps onto this tile.
     * When Chip enters a Force Floor, this method calculates the movement vector
     * (dx, dy) corresponding to the floor's direction and sends a request to the
     * Map to apply a "force" movement on the next update cycle.
     * @param map The current game map context.
     * @param chip The player character triggering the event.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        int dx = 0, dy = 0;
        switch(forceDirection) {
            case UP: dy = -1; break;
            case DOWN: dy = 1; break;
            case LEFT: dx = -1; break;
            case RIGHT: dx = 1; break;
            default: break; // Handles NONE or any other case by doing nothing
        }
        map.requestForce(dx, dy);
    }

    // GUI methods

    /**
     * Retrieves the specific direction this floor forces the player towards.
     * @return The Direction enum value (UP, DOWN, LEFT, or RIGHT).
     */
    public Direction getForceDirection() {
        return forceDirection;
    }

    /**
     * Generates a unique string identifier for this tile type.
     * This is typically used for internal logic, debugging, or saving/loading
     * to distinguish between different orientations of force floors.
     * @return A string concatenation of "ForceTile" and the direction name.
     */
    @Override
    public String getTileType(){
        return "ForceTile" + forceDirection.name();
    }

    /**
     * Provides the visual state key used by the rendering system.
     * This string corresponds to the specific sprite image (e.g., an arrow pointing up)
     * that should be drawn for this tile.
     * @return A lowercase string representing the direction (e.g., "up", "down").
     */
    @Override
    public String getVisualState(){
         switch(forceDirection) {
            case UP: return "up";
            case DOWN: return "down";
            case LEFT: return "left";
            case RIGHT: return "right";
            default: return "none";
        }
    }

}