/**
 * Represents the Flippers inventory item.
 * This essential piece of equipment grants the player (Chip) the ability to 
 * safely traverse Water tiles without drowning, effectively turning the water 
 * hazard into a passable surface.
 */
public class FlipperItem extends ItemTile {

    /**
     * Constructs a new FlipperItem at the specified coordinate.
     * Initializes the tile with the internal ID "Flippers", the display name "FlippersItem", 
     * and the visual asset key "flippers".
     * @param position The (x, y) coordinate where the Flippers are placed on the map.
     */
    public FlipperItem(Position position) {
        super(position, "Flippers", "FlippersItem", "flippers");
    }

    /**
     * Executed immediately when the player (Chip) enters the tile containing this item.
     * This handles the collection logic
     * @param map  The current instance of the game map.
     * @param chip The player entity collecting the item.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // 1. Equip the item: Grant the player the ability to walk on Water (canSwim = true).
        chip.getInventory().equipFlippers();
        
        // 2. Remove the physical tile from the board, consuming the item permanently.
        map.removeTile(this.getPosition());
    }
}