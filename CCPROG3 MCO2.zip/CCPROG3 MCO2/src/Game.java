/*
 * The backend connecting the MCO1 logic to the GUI.
 */

/**
 * Acts as the central controller for the game logic.
 * This class bridges the GUI and the underlying game mechanics (Map, Tile, Chip).
 * It manages the game state (playing, won, lost), handles level progression,
 * and coordinates the turn-based updates for the player and enemies.
 */
public class Game {
    private Map currentMap;
    private int currentLevel = 1;
    private final int TOTAL_LEVELS = 3;
    private boolean gameRunning = true;
    private GameState gameState = GameState.PLAYING;

    /**
     * Enumeration representing the various states of the game session.
     */
    public enum GameState{
        PLAYING,
        LEVEL_COMPLETE,
        GAME_COMPLETE,
        GAME_OVER,
        QUIT
    }

    /**
     * Constructs a new Game instance.
     * Initializes the game by loading the first level immediately.
     */
    public Game() {
        loadLevel(currentLevel);
    }

    /**
     * Loads the specific map data for a given level number.
     * This method utilizes the LevelLoader to generate the map layout
     * and resets the game state to PLAYING.
     * @param level The integer identifier of the level to load (e.g., 1, 2, 3).
     * @throws IllegalArgumentException if the provided level number is invalid.
     */
    private void loadLevel(int level) {
    Map map;
    switch(level) {
        case 1: map = LevelLoader.loadLevel1(); break;
        case 2: map = LevelLoader.loadLevel2(); break;
        case 3: map = LevelLoader.loadLevel3(); break;
        default: throw new IllegalArgumentException("Invalid level: " + level);
    }
    
    this.currentMap = map; // Assign the loaded map
    this.gameState = GameState.PLAYING; // Reset game state AFTER map is loaded
}

    /**
     * Attempts to move the main character (Chip) to a specific coordinate.
     * This method acts as a "turn" in the game loop. It performs the following:
     * 1. Validates if the game is active.
     * 2. Moves the player via the Map logic.
     * 3. Checks for immediate collision with enemies.
     * 4. Triggers enemy movement updates.
     * 5. Checks if the level completion conditions are met.
     * @param targetX The target x-coordinate on the grid.
     * @param targetY The target y-coordinate on the grid.
     * @return true if the player successfully moved; false if the move was blocked or invalid.
     */
    public boolean moveChip(int targetX, int targetY){
        if(gameState != GameState.PLAYING || !getChip().isAlive()){
            return false;
        }
         boolean moved = currentMap.moveChip(targetX, targetY);
        
        // (in lvl 3 only) Chip takes dmg from enemy
        Tile newTile = currentMap.getTileAt(targetX, targetY);
        if (newTile instanceof AngryTeethTile){
            getChip().takeDmg(1);
            if (!getChip().isAlive()){
                gameState = GameState.GAME_OVER;
            }
        }
        
        // Move enemies after player moves
        updateEnemies();

        // Check if level completed
        if (currentMap.isLevelCompleted() && currentMap.takeNextLevelRequest()) {
            if (currentLevel < TOTAL_LEVELS) {
                gameState = GameState.LEVEL_COMPLETE;
            } else {
                gameState = GameState.GAME_COMPLETE;
            }
        }
        
        return moved;
    }
    
    /**
     * Updates the behavior and position of enemies on the map.
     * Specifically handles logic for AngryTeethTile in Level 3.
     * It iterates through the grid to move enemies and checks for collisions
     * with the player (causing damage/Game Over).
     */
    public void updateEnemies(){
        if(currentLevel == 3){
            for (int y = 0; y < getMapHeight(); y++){
                for (int x = 0; x < getMapWidth(); x++){
                    Tile tile = getTileAt(x, y);
                    if (tile instanceof AngryTeethTile){
                        ((AngryTeethTile) tile).enemyMovement(currentMap);

                        Position enemyPos = tile.getPosition();
                        if (enemyPos.equals(getChip().getPosition())){
                        getChip().takeDmg(1);
                        if (!getChip().isAlive()){
                            gameState = GameState.GAME_OVER;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Checks if the game has ended due to player death.
     * @return true if the current state is GAME_OVER.
     */
    public boolean isGameOver(){
        return gameState == GameState.GAME_OVER;
    }

    /**
     * Advances the game to the next level.
     * If more levels exist, it increments the level counter, resets the player's
     * inventory, and loads the new map. If no levels remain, it sets the state
     * to GAME_COMPLETE.
     */
    public void continueToNextLevel() {
        if (currentLevel < TOTAL_LEVELS) {
            currentLevel++;

            getChip().getInventory().reset(); //resets inventory
            loadLevel(currentLevel);
        } else {
            gameState = GameState.GAME_COMPLETE;
            // gameRunning = false; a possible victory screen u might implement !
        }
    }

     /** Sets the game state to QUIT from the level completion screen.
      * Stops the game loop.
      */
    public void quitAfterLevelComplete() {
        gameState = GameState.QUIT;
        gameRunning = false;
    }

     /** Sets the game state to QUIT during active gameplay.
      * Stops the game loop.
      */
    public void quitGame() {
        gameState = GameState.QUIT;
        gameRunning = false;
    }

    /**
     * Retrieves the current operational state of the game.
     * @return The current gameState (e.g., PLAYING, GAME_OVER).
     */
    public GameState getGameState(){
        return gameState;
    }

    /**
     * Checks if the current level's objectives have been met.
     * @return true if the state is LEVEL_COMPLETE.
     */
    public boolean isLevelComplete(){
        return gameState == GameState.LEVEL_COMPLETE;
    }

    /**
     * Retrieves the currently active Map object.
     * @return The Map instance representing the current level.
     */
    public Map getCurrentMap(){
        return currentMap;
    }

    /**
     * Checks if the entire game (all levels) has been finished.
     * @return true if the state is GAME_COMPLETE.
     */
    public boolean isGameComplete(){
        return gameState == GameState.GAME_COMPLETE;
    }

    /**
     * Checks if there are subsequent levels available to play.
     * @return true if the current level is less than the total number of levels.
     */
    public boolean hasMoreLevels(){
        return currentLevel < TOTAL_LEVELS;
    } 

    /**
     * Retrieves the Chip (player) object from the current map.
     * @return The {@code Chip} instance.
     */
    public Chip getChip(){
        return currentMap.getChip();
    }

    /**
     * Retrieves the number of microchips the player has currently collected.
     * @return The count of collected chips.
     */
    public int getChipsCollected(){
        return currentMap.getChipsCollected();
    }

    /**
     * Retrieves the total number of microchips required to pass the current level.
     * @return The required chip count.
     */
    public int getChipsCollectedRequired(){
        return currentMap.getChipsRequired();
    }

    /**
     * Retrieves the current level number.
     * @return The integer index of the current level.
     */
    public int getLevel(){
        return currentLevel;
    }

    /**
     * Retrieves the specific Tile object at the given grid coordinates.
     * @param x The x-coordinate.
     * @param y The y-coordinate.
     * @return The Tile object at that position.
     */
    public Tile getTileAt(int x, int y){
        return currentMap.getTileAt(x, y);
    }

    /**
     * Retrieves the width of the current map.
     * @return The width in number of tiles.
     */
    public int getMapWidth(){
        return currentMap.getWidth();

    }

    /**
     * Retrieves the height of the current map.
     * @return The height in number of tiles.
     */
    public int getMapHeight(){
        return currentMap.getHeight();
    }

    /**
     * Checks if the application loop should continue running.
     * @return true if the game is active; false if it should exit.
     */
    public boolean isGameRunning(){
        return gameRunning;
    }
}