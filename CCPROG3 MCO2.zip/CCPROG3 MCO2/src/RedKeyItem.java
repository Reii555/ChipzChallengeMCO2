/**
 * Represents the collectable "Red Key" item tile.
 * This item is a requisite for passing through Red Door tiles. Unlike some items 
 * that provide passive abilities (like boots), keys are typically treated as 
 * currency or unlock tokens within the inventory system.
 */
public class RedKeyItem extends ItemTile {

    /**
     * Constructs a new Red Key item at the specified position.
     * Initializes the tile with the specific identifiers required for the 
     * red key logic and assets.
     * @param position The grid coordinates where this item is located.
     */
    public RedKeyItem(Position position){
        // Pass standard keys to the parent ItemTile
        super(position, "Red_key", "RedKeyItem", "redKey");
    }

    /**
     * Triggered when the Chip entity enters the tile.
     * This method executes the pickup logic:
     * 1. It increments the red key count in the player's inventory.
     * 2. It removes the tile from the map, preventing duplicate collection.
     * @param map  The current game map controller.
     * @param chip The Chip entity collecting the item.
     */
    @Override
    public void onEnter(Map map, Chip chip){
        // Update inventory state to reflect the new key
        chip.getInventory().addRedKey();

        // Physically remove the item from the game board
        map.removeTile(this.getPosition());
    }
}