import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;

/**
 * Represents the Heads-Up Display (HUD) or sidebar interface for the game.
 * * This component visualizes the player's current status, including remaining chips, 
 * lives count, current level, and the inventory (keys and boots). It acts as 
 * a visual observer of the game state.
 */
public class GameHUD extends VBox {

    // Reference to the game state to pull data from.
    private Map map;
    
    // Dynamic text labels.
    private Label chipsLeftLabel;
    private Label levelLabel;
    private Label livesLabel;
    private Label messageLabel;
    
    // Inventory Icons (Visual representations of items).
    private ImageView redKeyIcon, blueKeyIcon;
    private ImageView flippersIcon, fireBootsIcon, hikingBootsIcon;

    /**
     * Constructs the GameHUD and initializes the layout of the sidebar.
     * This sets up the visual hierarchy, styles (CSS-like styling), and 
     * initial placeholders for game statistics.
     * @param map The data model representing the game state, used to bind UI updates.
     */
    public GameHUD(Map map) {
        this.map = map;
        
        // Sidebar Styling 
        // Apply a grey background with a thick border to separate it from the game view.
        this.setStyle("-fx-background-color: #CCCCCC; -fx-border-color: #999999; -fx-border-width: 4;");
        this.setPadding(new Insets(20)); // Internal spacing
        this.setSpacing(10);             // Spacing between vertical elements
        this.setPrefWidth(170);          // Fixed width for the sidebar
        this.setAlignment(Pos.TOP_CENTER);

        // 1. Level Header Section
        levelLabel = createHeader("LEVEL");
        Label levelValue = createValue("1"); // Currently static, can be made dynamic later

        // 2. Lives Header Section
        Label livesHeader = createHeader("LIVES LEFT");
        livesLabel = createValue("3"); 

        // 3. Chips Counter Section
        Label chipsHeader = createHeader("CHIPS LEFT");
        chipsLeftLabel = createValue("0");

        // 4. Inventory Grid Setup
        // Uses a grid layout to arrange icons in a 2x3 matrix.
        GridPane inventoryGrid = new GridPane();
        inventoryGrid.setHgap(10); // Horizontal gap between icons
        inventoryGrid.setVgap(10); // Vertical gap between icons
        inventoryGrid.setAlignment(Pos.CENTER);

        // Initialize icons (dimmed by default via createIcon)
        redKeyIcon = createIcon(SpriteLoader.getRedKey());
        blueKeyIcon = createIcon(SpriteLoader.getBlueKey());
        flippersIcon = createIcon(SpriteLoader.getFlippers());
        fireBootsIcon = createIcon(SpriteLoader.getFireBoots());
        hikingBootsIcon = createIcon(SpriteLoader.getHikingBoots());

        // Add icons to specific grid coordinates (Column, Row)
        inventoryGrid.add(redKeyIcon, 0, 0);
        inventoryGrid.add(blueKeyIcon, 1, 0);
        inventoryGrid.add(flippersIcon, 0, 1);
        inventoryGrid.add(fireBootsIcon, 1, 1);
        inventoryGrid.add(hikingBootsIcon, 0, 2);

        // 5. Message Area Configuration
        // A dedicated area for game hints or warnings (e.g., "You need a red key").
        messageLabel = new Label("");
        messageLabel.setWrapText(true);
        messageLabel.setTextAlignment(TextAlignment.CENTER);
        messageLabel.setTextFill(Color.DARKRED);
        messageLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        messageLabel.setStyle("-fx-background-color: #DDDDDD; -fx-padding: 5; -fx-background-radius: 5;");
        messageLabel.setMaxWidth(Double.MAX_VALUE); // Allow it to stretch to sidebar width

        // 6. Footer Instruction
        Label helpLabel = new Label("Click ESC to pause");
        helpLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 11));
        helpLabel.setTextFill(Color.RED);
        helpLabel.setPadding(new Insets(15, 0, 0, 0)); // Add top padding to separate visually

        // Assemble all components into the main VBox container
        this.getChildren().addAll(
            levelLabel, levelValue, 
            createSeparator(),
            livesHeader, livesLabel, 
            createSeparator(),
            chipsHeader, chipsLeftLabel,
            createSeparator(),
            createHeader("INVENTORY"),
            inventoryGrid,
            createSeparator(),
            messageLabel,
            helpLabel 
        );
    }

    /**
     * Refreshes the HUD elements to reflect the current state of the game.
     * This method polls the Map and Player (Chip) objects to update the 
     * chips remaining, lives count, and inventory status. It handles the 
     * logic for "dimming" or "lighting up" inventory icons.
     */
    public void update() {
        Chip chip = map.getChip();
        if (chip != null) {
            // Calculate remaining chips
            int chipsNeeded = map.getChipsRequired() - map.getChipsCollected();
            // Clamp value to 0 to prevent negative numbers display
            if (chipsNeeded < 0) chipsNeeded = 0;
            chipsLeftLabel.setText(String.valueOf(chipsNeeded));

            // Update Lives
            livesLabel.setText(String.valueOf(chip.getHealth()));

            // Update Inventory Icons
            Inventory inv = chip.getInventory();
            setVisible(redKeyIcon, inv.hasRedKey());
            setVisible(blueKeyIcon, inv.hasBlueKey());
            setVisible(flippersIcon, inv.canSwim());
            setVisible(fireBootsIcon, inv.canWalkOnFire());
            setVisible(hikingBootsIcon, inv.canWalkOnMud());
        }
    }
    
    /**
     * Displays a text notification or warning to the user in the designated message area.
     * @param msg The string message to display.
     */
    public void showMessage(String msg) {
        messageLabel.setText(msg);
    }

    /**
     * Removes the currently displayed message, resetting the message area to empty.
     */
    public void clearMessage() {
        messageLabel.setText("");
    }

    // Helper Methods (Internal UI Factories) 

    /**
     * Factory method to create a stylized section header label.
     * @param text The text to display (e.g., "LEVEL").
     * @return A configured Label object.
     */
    private Label createHeader(String text) {
        Label lbl = new Label(text);
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        lbl.setTextFill(Color.DARKRED);
        return lbl;
    }

    /**
     * Factory method to create a "digital clock" style value display.
     * Creates a label with a black background and green text to simulate 
     * an LCD display.
     * @param text The initial value text.
     * @return A styled Label object.
     */
    private Label createValue(String text) {
        Label lbl = new Label(text);
        lbl.setFont(Font.font("Monospaced", FontWeight.BOLD, 30));
        lbl.setTextFill(Color.BLACK); 
        // Inline CSS for the LCD effect
        lbl.setStyle("-fx-background-color: black; -fx-text-fill: #00FF00; -fx-padding: 5; -fx-alignment: center;");
        lbl.setPrefWidth(100); 
        lbl.setAlignment(Pos.CENTER);
        return lbl;
    }

    /**
     * Initializes an inventory icon sprite.
     * Sets the default size and sets opacity to low (dimmed) to indicate
     * the item is not yet collected.
     * @param img The source image for the icon.
     * @return A configured ImageView.
     */
    private ImageView createIcon(javafx.scene.image.Image img) {
        ImageView iv = new ImageView(img);
        iv.setFitWidth(32);
        iv.setFitHeight(32);
        iv.setOpacity(0.2); // Start dimmed (0.2 opacity)
        return iv;
    }

    /**
     * Toggles the visual availability of an inventory icon.
     * Instead of removing the node, we toggle opacity. 
     * 1.0 means the player has the item; 0.2 means they do not.
     * @param iv      The ImageView to modify.
     * @param visible True if the player has the item, False otherwise.
     */
    private void setVisible(ImageView iv, boolean visible) {
        iv.setOpacity(visible ? 1.0 : 0.2); 
    }
    
    /**
     * Creates a simple text-based visual separator.
     * @return A Label containing dashes to act as a divider.
     */
    private Label createSeparator() {
        Label sep = new Label("----------------");
        sep.setTextFill(Color.GREY);
        return sep;
    }
}