import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

import java.util.HashMap;
import java.util.Map;

/**
 * The centralized asset manager for the game's graphics.
 * <p>
 * This class is responsible for loading the master sprite sheet, slicing it into individual
 * 32x32 tiles, applying transparency filters, and caching the results for performance.
 * It provides static accessor methods to retrieve specific game elements (terrain, items, actors)
 * without exposing the underlying sprite sheet coordinates to the rest of the application.
 * </p>
 */
public class SpriteLoader {

    private static final String SHEET_PATH = "tiles.png"; 
    private static final int TILE_SIZE = 32;

    // The main source image containing all game assets
    private static Image spriteSheet;
    
    // A cache map to store processed images so we don't re-slice or re-filter them unnecessarily
    private static final Map<String, Image> cache = new HashMap<>();

    // --- SPRITE SHEET COORDINATES ---
    // These constants map logical game objects to their X (col) and Y (row) positions on the sheet.

    // Terrain
    private static final int COL_FLOOR = 0, ROW_FLOOR = 2;    
    private static final int COL_WALL = 1, ROW_WALL = 2;      
    private static final int COL_ICE = 10, ROW_ICE = 1;       
    private static final int COL_WATER = 10, ROW_WATER = 2; 
    private static final int COL_MUD = 4, ROW_MUD = 31; 

    // Exit
    private static final int ROW_EXIT = 2;
    private static final int COL_EXIT_START = 6; 
    private static final int EXIT_FRAMES = 4; 

    // Hazards
    private static final int ROW_FIRE = 29;
    private static final int COL_FIRE = 12;

    // Enemy (AngryTeeth)
    private static final int ROW_ENEMY = 11;
    private static final int COL_ENEMY_FRONT = 0; 
    private static final int COL_ENEMY_RIGHT = 3;
    private static final int COL_ENEMY_LEFT = 6;

    // Collectible Items
    private static final int COL_CHIP_ITEM = 11, ROW_CHIP_ITEM = 3; 
    private static final int COL_KEY_RED = 4, ROW_KEY_RED = 1;
    private static final int COL_KEY_BLUE = 5, ROW_KEY_BLUE = 1;
    private static final int COL_DOOR_RED = 0, ROW_DOOR_RED = 1;    
    private static final int COL_DOOR_BLUE = 1, ROW_DOOR_BLUE = 1;  
    private static final int COL_FLIPPERS = 0, ROW_FLIPPERS = 6;   
    private static final int COL_FIRE_BOOTS = 1, ROW_FIRE_BOOTS = 6; 
    private static final int COL_HIKE_BOOTS = 4, ROW_HIKE_BOOTS = 6; 

    // Force Floors (Conveyor Belts)
    private static final int ROW_FORCE = 19;      
    private static final int ROW_FORCE_LEFT = 20; 
    private static final int COL_FORCE_UP = 0;
    private static final int COL_FORCE_DOWN = 1;
    private static final int COL_FORCE_RIGHT = 3;
    private static final int COL_FORCE_LEFT = 3; 
    
    // Chip Animation Configuration
    private static final int CHIP_ANIM_FRAMES = 4;

    /**
     * Loads the main sprite sheet image into memory.
     * This method must be called once at the start of the application (in Main.java)
     * before any sprites are requested.
     */
    public static void initialize() {
        try {
            spriteSheet = new Image(SpriteLoader.class.getResourceAsStream(SHEET_PATH));
            if (spriteSheet.isError()) System.err.println("Failed to load sprite sheet: " + SHEET_PATH);
        } catch (Exception e) { e.printStackTrace(); }
    }

    /**
     * Internal helper to extract a single tile from the sprite sheet.
     * This method implements a caching mechanism: if a sprite has been requested before,
     * the cached version is returned to save processing time.
     *
     * @param col The 0-based column index of the tile in the sprite sheet.
     * @param row The 0-based row index of the tile.
     * @param transparent If true, the "green screen" background will be removed from the image.
     * Use 'true' for items/actors, and 'false' for solid terrain (walls/floor).
     * @return The processed JavaFX Image object for the requested tile.
     */
    private static Image getSprite(int col, int row, boolean transparent) {
        String key = col + "," + row + "," + transparent;
        
        // Check cache first
        if (cache.containsKey(key)) return cache.get(key);
        
        // Ensure sheet is loaded
        if (spriteSheet == null) initialize();

        PixelReader reader = spriteSheet.getPixelReader();
        WritableImage rawImage = new WritableImage(reader, col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        
        Image finalImage;
        if (transparent) {
            finalImage = makeTransparent(rawImage);
        } else {
            finalImage = rawImage; 
        }
        
        // Store in cache for future use
        cache.put(key, finalImage);
        return finalImage;
    }

    /**
     * Applies a chroma-key filter to an image, converting the specific neon-green background
     * color into fully transparent pixels. This allows items and characters to be layered
     * cleanly on top of floor tiles without a colored box around them.
     *
     * @param input The raw image sliced from the sprite sheet.
     * @return A new Image with the green background replaced by transparency.
     */
    private static Image makeTransparent(Image input) {
        int w = (int) input.getWidth();
        int h = (int) input.getHeight();
        WritableImage output = new WritableImage(w, h);
        PixelReader reader = input.getPixelReader();
        PixelWriter writer = output.getPixelWriter();

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                Color c = reader.getColor(x, y);
                // Heuristic check: if pixel is very Green and has low Red/Blue, it is background.
                if (c.getGreen() > 0.4 && c.getGreen() > c.getRed() + 0.2 && c.getGreen() > c.getBlue() + 0.2) {
                    writer.setColor(x, y, Color.TRANSPARENT);
                } else {
                    writer.setColor(x, y, c);
                }
            }
        }
        return output;
    }

    // --- PUBLIC ACCESSORS ---
    // These methods provide a clean interface for GameView to get specific tiles.

    public static Image getFloor() { return getSprite(COL_FLOOR, ROW_FLOOR, false); }
    public static Image getWall() { return getSprite(COL_WALL, ROW_WALL, false); }
    public static Image getIce() { return getSprite(COL_ICE, ROW_ICE, false); }
    public static Image getWater() { return getSprite(COL_WATER, ROW_WATER, false); }
    public static Image getMud() { return getSprite(COL_MUD, ROW_MUD, false); } 
    public static Image getRedDoor() { return getSprite(COL_DOOR_RED, ROW_DOOR_RED, false); }
    public static Image getBlueDoor() { return getSprite(COL_DOOR_BLUE, ROW_DOOR_BLUE, false); }
    public static Image getFire() { return getSprite(COL_FIRE, ROW_FIRE, false); }
    
    /**
     * Retrieves a frame for the Exit animation.
     * @param frameIndex The current animation frame (cycled by GameView).
     * @return The image for the spinning exit portal.
     */
    public static Image getExitFrame(int frameIndex) {
        int col = COL_EXIT_START + (frameIndex % EXIT_FRAMES);
        return getSprite(col, ROW_EXIT, false); 
    }

    /**
     * Retrieves the appropriate Force Floor (Conveyor) sprite based on direction.
     * @param d The direction the force floor pushes towards.
     * @return The matching arrow sprite.
     */
    public static Image getForceFloor(Direction d) {
        switch (d) {
            case UP:    return getSprite(COL_FORCE_UP, ROW_FORCE, false);
            case DOWN:  return getSprite(COL_FORCE_DOWN, ROW_FORCE, false);
            case RIGHT: return getSprite(COL_FORCE_RIGHT, ROW_FORCE, false);
            case LEFT:  return getSprite(COL_FORCE_LEFT, ROW_FORCE_LEFT, false);
            default:    return getFloor();
        }
    }

    public static Image getRedKey() { return getSprite(COL_KEY_RED, ROW_KEY_RED, true); }
    public static Image getBlueKey() { return getSprite(COL_KEY_BLUE, ROW_KEY_BLUE, true); }
    public static Image getMicrochip() { return getSprite(COL_CHIP_ITEM, ROW_CHIP_ITEM, true); }
    public static Image getFlippers() { return getSprite(COL_FLIPPERS, ROW_FLIPPERS, true); }
    public static Image getFireBoots() { return getSprite(COL_FIRE_BOOTS, ROW_FIRE_BOOTS, true); }
    public static Image getHikingBoots() { return getSprite(COL_HIKE_BOOTS, ROW_HIKE_BOOTS, true); } 

    /**
     * Retrieves the sprite for the "Angry Teeth" enemy.
     * @param d The direction the enemy is moving/facing.
     * @return The enemy sprite with transparency applied.
     */
    public static Image getEnemy(Direction d) {
        if (d == null) d = Direction.DOWN; 
        int col = COL_ENEMY_FRONT;
        switch (d) {
            case UP:    col = COL_ENEMY_FRONT; break;
            case LEFT:  col = COL_ENEMY_LEFT; break;
            case RIGHT: col = COL_ENEMY_RIGHT; break;
            case DOWN:
            default:    col = COL_ENEMY_FRONT; break;
        }
        return getSprite(col, ROW_ENEMY, true);
    }

    /**
     * Retrieves the animated sprite for the player character (Chip).
     * This handles the logic for selecting the correct row (direction) and 
     * column (walking frame) from the sprite sheet.
     *
     * @param d The direction Chip is currently facing.
     * @param frame The animation frame index (managed by the game loop).
     * @return The specific frame of Chip walking.
     */
    public static Image getChip(Direction d, int frame) {
        if (d == null) d = Direction.DOWN;
        
        int row = 23; // Default Row (Down)
        int colStart = 0; // Default Col

        // Determine row and start column based on facing direction
        switch (d) {
            case UP:    
                row = 22; colStart = 0; break;
            case RIGHT: 
                row = 22; colStart = 8; break; 
            case LEFT:  
                row = 23; colStart = 8; break; 
            case DOWN:  
            default:    
                row = 23; colStart = 0; break;
        }

        // Calculate the final column by offsetting the start column with the frame index.
        // Modulo ensures the frame index loops safely within the available frames.
        int finalCol = colStart + (frame % CHIP_ANIM_FRAMES);

        return getSprite(finalCol, row, true);
    }
}