/**
 * Represents the collectable "Fire Boots" equipment item tile.
 * When collected, this item grants the Chip entity a passive, permanent ability 
 * to safely walk across FireTile hazards without taking damage or dying.
 */
public class FireBootsItem extends ItemTile {
    
    /**
     * Constructs a new Fire Boots item at the specified position.
     * Initializes the tile with the specific logical and visual identifiers 
     * required for the game system.
     * @param position The grid coordinates where this item is located.
     */
    public FireBootsItem(Position position){
        // Pass standard keys to the parent ItemTile
        super(position, "Fire_boots", "FireBootsItem", "fireBoots");
    }

    /**
     * Triggered when the Chip entity enters the tile.
     * This method executes the collection and equipping logic
     * @param map  The current game map controller.
     * @param chip The Chip entity collecting the item.
     */
    @Override
    public void onEnter(Map map, Chip chip){
        // Equip the boots, granting fire immunity
        chip.getInventory().equipFireBoots();
        
        // Remove the item from the world, turning the spot into an empty floor tile
        map.removeTile(this.getPosition());
    }
}