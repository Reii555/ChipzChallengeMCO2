/**
 * Represents the Blue Key collectible item.
 * This item is required to unlock and pass through corresponding **Blue Door** tiles 
 * found throughout the level. Once collected, it is permanently added to the 
 * player's inventory until it is used to open a door.
 */
public class BlueKeyItem extends ItemTile {

    /**
     * Constructs a new BlueKeyItem at the specified coordinate.
     * Initializes the tile with the internal ID "Blue_key", the display name "BlueKeyItem", 
     * and the visual asset key "blueKey".
     * @param position The (x, y) coordinate where the Blue Key is placed on the map.
     */
    public BlueKeyItem(Position position) {
        super(position, "Blue_key", "BlueKeyItem", "blueKey");
    }

    /**
     * Executed immediately when the player (Chip) enters the tile containing this item.
     * This handles the collection logic
     * @param map  The current instance of the game map.
     * @param chip The player entity collecting the item.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // 1. Add the key to the player's inventory, increasing the count of available Blue Keys.
        chip.getInventory().addBlueKey();

        // 2. Remove the physical tile from the board, consuming the item permanently.
        map.removeTile(this.getPosition());
    }

}
