public abstract class ItemTile extends Tile {
    private String itemState;
    private String tileType;
    private String visualState;

    /**
     * Constructs a new abstract ItemTile.
     * This constructor serves as the base for all collectible items (keys, boots, etc.).
     * It initializes the core identifiers used for logic and rendering.
     * @param position The grid coordinates where this item is located.
     * @param itemState A specific identifier for the item's state (e.g., "red", "fire_boots").
     * @param tileType The general category of the tile (e.g., "KeyTile", "BootsTile").
     * @param visualState The string key used to look up the correct sprite image.
     */
    public ItemTile(Position position, String itemState, String tileType, String visualState){
        super(position);
        this.itemState = itemState;
        this.tileType = tileType;
        this.visualState = visualState;
    }

    /**
     * Determines if the player is permitted to enter this tile.
     * Collectible items are never solid obstacles; the player simply walks onto them
     * to pick them up. Therefore, this always returns true.
     * @param c The instance of the player character (Chip).
     * @return true always, indicating the tile is passable.
     */
    @Override
    public boolean isPassable(Chip c){
        return true;
    }

    /**
     * Defines the logic executed when the player steps onto this item.
     * Because this is an abstract class, the specific behavior (e.g., adding a key
     * to the inventory vs. equipping boots) must be implemented by the concrete subclasses.
     * @param map The current game map context.
     * @param chip The player character triggering the event.
     */
    @Override
    public abstract void onEnter(Map map, Chip chip);

    /**
     * Retrieves the specific state identifier for this item.
     * @return A string representing the specific variant of the item (e.g., "blue" for a blue key).
     */
    public String getItemState(){ 
        return itemState; 
    }

    /**
     * Retrieves the general category name of this tile.
     * @return A string representing the class type (e.g., "KeyTile").
     */
    public String getTileType(){
        return tileType;
    }

    /**
     * Retrieves the visual key used by the rendering system.
     * @return A string representing the sprite to be drawn.
     */
    public String getVisualState(){ 
        return visualState;
    }
}