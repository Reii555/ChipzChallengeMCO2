/**
 * Represents the Exit tile, which serves as the goal for the player.
 * Stepping on this tile triggers the end of the level, but only if the
 * player has collected all required microchips.
 */
public class ExitTile extends Tile {

    /**
     * Constructs a new Exit Tile at the specified position.
     * @param position The grid coordinates where this tile is located.
     */
    public ExitTile(Position position){
        super(position);
    }

    /**
     * Determines if the player is permitted to enter this tile.
     * The Exit tile is not an obstacle, allowing the player to step onto it freely.
     * @param c The instance of the player character (Chip).
     * @return true always, indicating the tile is passable.
     */
    @Override
    public boolean isPassable(Chip c){
        return true; // Exit tiles are always passable
    }

    /**
     * Executes the logic when the player steps onto the Exit tile.
     * This method checks the {Map to see if all necessary microchips have been
     * collected. If the level is complete, it requests the transition to the next level.
     * @param map The current game map context.
     * @param chip The player character triggering the event.
     */
    @Override
    public void onEnter(Map map, Chip chip){
        if (map.isLevelCompleted()) {
            map.requestNextLevel();
        }
    }

    /**
     * Retrieves the unique string identifier for this tile type.
     * @return The string "EXIT".
     */
    @Override
    public String getTileType(){
        return "EXIT";
    }

     /**
      * Provides the visual state key used by the rendering system.
      * @return The string "exit" corresponding to the exit sprite.
      */
     @Override
    public String getVisualState(){
        return "exit";
    }
}