/**
 * Represents a locked Blue Door tile in the game map.
 * This tile is a temporary obstacle that can only be passed if the player 
 * (Chip) possesses a Blue Key item. Upon successful entry, one Blue Key 
 * is consumed, and the door tile is permanently removed from the map.
 */
public class BlueDoorTile extends DoorTile {

    /**
     * Constructs a new Blue Door tile at the specified grid position.
     * Initializes the tile with the color identifier "blue" and the appropriate 
     * logical and visual keys.
     * @param position The coordinate location of this door tile.
     */
    public BlueDoorTile(Position position) {
        // Pass standard keys to the parent DoorTile
        super(position, "blue", "BlueDoorTile", "blue_door");
    }

    /**
     * Determines if the provided Chip entity is permitted to enter this tile.
     * Access is granted only if the Chip's inventory contains at least one Blue Key.
     * @param c The Chip entity attempting to move.
     * @return true if the Chip has a Blue Key; false otherwise.
     */
    @Override
    public boolean isPassable(Chip c) {
        return c.getInventory().hasBlueKey();
    }

    /**
     * Triggered immediately when the Chip entity successfully steps onto the tile.
     * This method executes the door opening sequence:
     * 1. If the Chip has the required key (check is redundant but safe), one key is consumed.
     * 2. The BlueDoorTile is removed from the map and replaced by a standard floor tile.
     *
     * @param map  The current game map controller.
     * @param chip The Chip entity that has just entered the tile.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        if (chip != null && chip.getInventory().hasBlueKey()) {
            // Consume the key and unlock the path
            chip.getInventory().useBlueKey();
            
            // Remove door after opening, clearing the path permanently
            map.removeTile(this.getPosition()); 
        }
    }
}