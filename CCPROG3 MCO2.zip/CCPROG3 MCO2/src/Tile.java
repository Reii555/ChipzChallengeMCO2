/**
 * Represents the abstract base class for all grid elements in the game world.
 * This class defines the fundamental contract that every tile must follow. 
 * Whether it is a static Wall, a dangerous Water hazard, or a collectible Key, 
 * every object on the grid shares these core properties (positioning) and 
 * behaviors (collision and interaction).
 */
public abstract class Tile {
    
    // The (x, y) coordinates of this tile within the Map grid.
    private Position position;

    /**
     * Constructs a new Tile object at the specified coordinates.
     * @param position The initial (x, y) location of this tile.
     */
    public Tile(Position position){
        this.position = position;
    }

    /**
     * Retrieves the current grid coordinates of this tile.
     * Used by the Map and Renderer to determine where this object is located logically 
     * and visually.
     * @return The Position object containing the x and y coordinates.
     */
    public Position getPosition() {
        return position;
    }

    /**
     * Updates the grid coordinates of this tile.
     * This is marked `protected` to restrict movement logic to the Map or the Tile 
     * itself, preventing external classes from arbitrarily teleporting tiles.
     * @param pos The new Position object.
     */
    protected void setPosition(Position pos) {
        this.position = pos; 
    }

    // Abstract Behavioral Methods

    /**
     * Determines if the player (Chip) is allowed to step onto this tile.
     * This acts as the collision detection logic. Before moving, the game checks 
     * this method. If it returns false, the player is blocked (like a Wall). 
     * If true, the move proceeds.
     * @param c The Chip (player) entity attempting the move.
     * @return true if the player can enter the tile; false if movement is blocked.
     */
    public abstract boolean isPassable(Chip c);

    /**
     * Defines the logic triggered immediately after the player enters this tile.
     * This handles gameplay interactions such as:
     * 1. Collecting items (Keys, Microchips).
     * 2. Triggering hazards (Water, Fire, Bombs).
     * 3. Changing player state (Sliding on Ice/Mud).
     * @param map  The current instance of the game map, allowing the tile to modify the world.
     * @param chip The player entity interacting with the tile.
     */
    public abstract void onEnter(Map map, Chip chip);

    // GUI / System Methods 

    /**
     * Retrieves a unique string identifier for the specific type of tile.
     * Used primarily for serialization (saving/loading levels) or debugging 
     * to identify the class type without using `instanceof`.
     * @return A string representing the class name (e.g., "WallTile", "WaterTile").
     */
    public abstract String getTileType();

    /**
     * Retrieves the visual key required to render this tile.
     * The GameView uses this string to look up the correct image asset 
     * (sprite) from the resource loader.
     * @return A string key mapping to an image asset (e.g., "wall", "water").
     */
    public abstract String getVisualState();
    
}