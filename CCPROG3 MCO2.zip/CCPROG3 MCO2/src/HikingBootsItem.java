/**
 * Represents the collectable "Hiking Boots" item tile.
 * When collected, this item grants the player the passive ability to traverse 
 * rough terrain (such as Dirt or Gravel) without negative effects (like sliding 
 * or being blocked).
 */
public class HikingBootsItem extends ItemTile {

    /**
     * Constructs a new Hiking Boots item at the specified position.
     * Initializes the tile with standard identifiers for the renderer and logic systems.
     * @param position The grid coordinates where this item is located.
     */
    public HikingBootsItem(Position position) {
        // Pass standard keys to the parent ItemTile
        super(position, "Hiking_Boots", "HikingBootsItem", "hiking_boots");
    }

    /**
     * Triggered when the Chip entity enters the tile.
     * This method handles the collection logic:
     * 1. It updates the Chip's inventory to flag that Hiking Boots are equipped.
     * 2. It removes this tile from the map, effectively consuming the item.
     * @param map  The current game map controller.
     * @param chip The Chip entity collecting the item.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // Grant the ability to walk on rough terrain
        chip.getInventory().equipHikingBoots();
        
        // Remove the item from the world so it cannot be picked up again
        map.removeTile(this.getPosition());
    }
}