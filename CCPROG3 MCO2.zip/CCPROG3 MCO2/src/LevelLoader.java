/**
 * A utility class responsible for designing and loading game levels.
 * This class acts as a database of level configurations, constructing
 * the map layout, placing terrain, items, hazards, and actors for each stage.
 */
public class LevelLoader {

    /**
     * Constructs and loads the layout for Level 1.
     * This level introduces basic mechanics: movement, walls, keys, and microchips.
     * It also features a small water section requiring Flippers.
     * @return A Map object populated with Level 1 tiles and entities.
     */
    public static Map loadLevel1() {
        int width = 10, height = 10;
        Position start = new Position(4, 1);
        int chipsRequired = 3;
        
        Chip chip = new Chip(start);
        Map map = new Map(width, height, chip, chipsRequired);
        
        // 1. Initialize the base terrain (Floor)
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                map.setTile(new Position(x, y), new FloorTile(new Position(x, y)));
            }
        }

        // 2. Construct the outer boundary walls
        for(int x = 0; x < width; x++){
            map.setTile(new Position(x, 0), new WallTile(new Position(x, 0))); // Top border
            map.setTile(new Position(x, height-1), new WallTile(new Position(x, height-1))); // Bottom border
        }

        for(int y = 0; y < height; y++){
            map.setTile(new Position(0, y), new WallTile(new Position(0, y))); // Left border
            map.setTile(new Position(width-1, y), new WallTile(new Position(width-1, y))); // Right border
        }

        // 3. Place Interior Walls to form the maze structure
        map.setTile(new Position(4, 8), new WallTile(new Position(4, 8)));
        map.setTile(new Position(5, 8), new WallTile(new Position(5, 8)));
        map.setTile(new Position(6, 8), new WallTile(new Position(6, 8)));
        map.setTile(new Position(7, 8), new WallTile(new Position(7, 8)));

        map.setTile(new Position(6, 7), new WallTile(new Position(6, 7)));
        map.setTile(new Position(7, 7), new WallTile(new Position(8, 7))); // Note: Visual offset wall

        map.setTile(new Position(1, 6), new WallTile(new Position(1, 6)));
        map.setTile(new Position(2, 6), new WallTile(new Position(2, 6)));
        map.setTile(new Position(3, 6), new WallTile(new Position(3, 6)));
        map.setTile(new Position(4, 6), new WallTile(new Position(4, 6)));

        map.setTile(new Position(2, 4), new WallTile(new Position(2, 4)));
        map.setTile(new Position(3, 4), new WallTile(new Position(3, 4)));
        map.setTile(new Position(5, 4), new WallTile(new Position(5, 4)));
        
        map.setTile(new Position(3, 3), new WallTile(new Position(3, 3)));
        map.setTile(new Position(4, 3), new WallTile(new Position(4,3)));
        map.setTile(new Position(5, 3), new WallTile(new Position(5, 3)));
        map.setTile(new Position(6, 3), new WallTile(new Position(6, 3)));

        map.setTile(new Position(3, 2), new WallTile(new Position(3, 2)));
        map.setTile(new Position(4, 2), new WallTile(new Position(4, 2)));
        
        map.setTile(new Position(3, 1), new WallTile(new Position(3, 1)));

        // 4. Place Hazards (Water and Fire)
        map.setTile(new Position(6, 1), new WaterTile(new Position(6, 1)));
        map.setTile(new Position(7, 1), new WaterTile(new Position(7, 1)));
        map.setTile(new Position(8, 1), new WaterTile(new Position(8, 1)));

        map.setTile(new Position(6, 2), new WaterTile(new Position(6, 2)));
        map.setTile(new Position(7, 2), new WaterTile(new Position(7, 2)));
        map.setTile(new Position(8, 2), new WaterTile(new Position(8, 2)));

        map.setTile(new Position(7, 3), new WaterTile(new Position(7, 3)));
        map.setTile(new Position(8, 3), new WaterTile(new Position(8, 3)));

        map.setTile(new Position(8, 7), new FireTile(new Position(8, 7)));

        // 5. Place Doors and Exit
        map.setTile(new Position(4, 7), new RedDoorTile(new Position(4, 7)));
        map.setTile(new Position(1, 4), new BlueDoorTile(new Position(1, 4)));
        map.setTile(new Position(8, 8), new ExitTile(new Position(8, 8)));

        // 6. Place Collectible Items
        map.setTile(new Position(1, 1), new Microchip(new Position(1, 1)));
        map.setTile(new Position(5, 2), new Microchip(new Position(5, 2)));
        map.setTile(new Position(1, 7), new Microchip(new Position(1, 7)));
        
        map.setTile(new Position(2, 1), new RedKeyItem(new Position(2, 1)));
        map.setTile(new Position(4, 4), new BlueKeyItem(new Position(4, 4)));
        map.setTile(new Position(1, 8), new FireBootsItem(new Position(1, 8)));
        map.setTile(new Position(5, 1), new FlipperItem(new Position(5, 1)));

        return map;
    }

    /**
     * Constructs and loads the layout for Level 2.
     * This level introduces Force Floors (conveyor belts) which push Chip automatically.
     * It serves as a tutorial for handling forced movement mechanics.
     * @return A Map object populated with Level 2 tiles and entities.
     */
    public static Map loadLevel2() {
        int width = 10, height = 10;
        Position start = new Position(8, 8);
        int chipsRequired = 3;
        
        Chip chip = new Chip(start);
        Map map = new Map(width, height, chip, chipsRequired);
        
        // Initialize floor
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                map.setTile(new Position(x, y), new FloorTile(new Position(x, y)));
            }
        }

        // Outer Walls
        for(int x = 0; x < width; x++){
            map.setTile(new Position(x, 0), new WallTile(new Position(x, 0))); 
            map.setTile(new Position(x, height-1), new WallTile(new Position(x, height-1))); 
        }

        for(int y = 0; y < height; y++){
            map.setTile(new Position(0, y), new WallTile(new Position(0, y))); 
            map.setTile(new Position(width-1, y), new WallTile(new Position(width-1, y))); 
        }

        // Interior Walls
        map.setTile(new Position(2, 8), new WallTile(new Position(2, 8)));
        map.setTile(new Position(2, 7), new WallTile(new Position(2, 7)));
        map.setTile(new Position(2, 6), new WallTile(new Position(2, 6)));
        map.setTile(new Position(3, 6), new WallTile(new Position(3, 6)));
        map.setTile(new Position(4, 6), new WallTile(new Position(4, 6))); 
        map.setTile(new Position(7, 6), new WallTile(new Position(7, 6)));
        map.setTile(new Position(8, 6), new WallTile(new Position(8, 6)));

        map.setTile(new Position(3, 5), new WallTile(new Position(3, 5)));
        map.setTile(new Position(4, 5), new WallTile(new Position(4, 5)));
        map.setTile(new Position(5, 5), new WallTile(new Position(5, 5)));

        map.setTile(new Position(3, 4), new WallTile(new Position(3, 4)));
        map.setTile(new Position(8, 4), new WallTile(new Position(8, 4)));

        map.setTile(new Position(3, 3), new WallTile(new Position(3, 3)));
        map.setTile(new Position(4, 3), new WallTile(new Position(4, 3)));
        map.setTile(new Position(7, 3), new WallTile(new Position(7, 3)));
        map.setTile(new Position(8, 3), new WallTile(new Position(8, 3)));

        map.setTile(new Position(3, 2), new WallTile(new Position(3, 2)));
        map.setTile(new Position(4, 2), new WallTile(new Position(4, 2)));
        map.setTile(new Position(6, 2), new WallTile(new Position(6, 2)));
        map.setTile(new Position(7, 2), new WallTile(new Position(7, 2)));
        map.setTile(new Position(8, 2), new WallTile(new Position(8, 2)));

        map.setTile(new Position(6, 1), new WallTile(new Position(6, 1)));
        map.setTile(new Position(7, 1), new WallTile(new Position(7, 1)));
        map.setTile(new Position(8, 1), new WallTile(new Position(8, 1)));

        // Hazards
        map.setTile(new Position(1, 7), new WaterTile(new Position(1, 7)));
        map.setTile(new Position(4, 8), new FireTile(new Position(4, 8)));
        map.setTile(new Position(4, 7), new FireTile(new Position(4, 7)));

        // Force Floors 
        map.setTile(new Position(1, 3), new ForceFloor(new Position(1,3), Direction.DOWN));
        map.setTile(new Position(2, 3), new ForceFloor(new Position(2,3), Direction.DOWN));
        map.setTile(new Position(1, 4), new ForceFloor(new Position(1,4), Direction.DOWN));
        map.setTile(new Position(2, 4), new ForceFloor(new Position(2,4), Direction.DOWN));

        // Objectives
        map.setTile(new Position(1, 8), new ExitTile(new Position(1,8)));
        map.setTile(new Position(4, 1), new RedDoorTile(new Position(4,1)));
        map.setTile(new Position(1, 6), new BlueDoorTile(new Position(1,6)));

        // Items
        map.setTile(new Position(3, 7), new Microchip(new Position(3,7)));
        map.setTile(new Position(2, 5), new Microchip(new Position(2,5)));
        map.setTile(new Position(4, 4), new Microchip(new Position(4,4)));

        map.setTile(new Position(6, 3), new RedKeyItem(new Position(6,3)));
        map.setTile(new Position(3, 8), new BlueKeyItem(new Position(3,8)));
        map.setTile(new Position(8, 5), new FireBootsItem(new Position(8,5)));
        map.setTile(new Position(7, 4), new FlipperItem(new Position(7,4)));

        return map;
    }

    /**
     * Constructs and loads the layout for Level 3.
     * This level features Ice Tiles (slippery surfaces) and an Enemy (Angry Teeth).
     * The player must navigate slippery terrain while avoiding the patrolling enemy.
     * @return A Map object populated with Level 3 tiles and entities.
     */
    public static Map loadLevel3() {
        int width = 10, height = 10;
        Position start = new Position(1, 8);
        int chipsRequired = 3;
        
        Chip chip = new Chip(start);
        Map map = new Map(width, height, chip, chipsRequired);
        
        // Initialize floor
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                map.setTile(new Position(x, y), new FloorTile(new Position(x, y)));
            }
        }

        // Walls
        for(int x = 0; x < width; x++){
            map.setTile(new Position(x, 0), new WallTile(new Position(x, 0))); 
            map.setTile(new Position(x, height-1), new WallTile(new Position(x, height-1))); 
        }

        for(int y = 0; y < height; y++){
            map.setTile(new Position(0, y), new WallTile(new Position(0, y))); 
            map.setTile(new Position(width-1, y), new WallTile(new Position(width-1, y))); 
        }

        // Interior Walls
        map.setTile(new Position(6, 7), new WallTile(new Position(6,7)));
        map.setTile(new Position(1, 6), new WallTile(new Position(1,6)));
        map.setTile(new Position(2, 6), new WallTile(new Position(2,6)));
        map.setTile(new Position(4, 6), new WallTile(new Position(4,6)));
        map.setTile(new Position(6, 6), new WallTile(new Position(6,6)));
        map.setTile(new Position(1, 5), new WallTile(new Position(1,5)));
        map.setTile(new Position(2, 5), new WallTile(new Position(2,5)));
        map.setTile(new Position(3, 5), new WallTile(new Position(3,5)));
        map.setTile(new Position(4, 5), new WallTile(new Position(4,5)));
        map.setTile(new Position(6, 5), new WallTile(new Position(6,5)));
        map.setTile(new Position(4, 4), new WallTile(new Position(4,4)));
        map.setTile(new Position(6, 4), new WallTile(new Position(6,4)));
        map.setTile(new Position(4, 3), new WallTile(new Position(4,3)));
        map.setTile(new Position(6, 3), new WallTile(new Position(6,3)));
        map.setTile(new Position(7, 3), new WallTile(new Position(4,3)));
        map.setTile(new Position(8, 3), new WallTile(new Position(6,3)));

        // Ice Tiles 
        map.setTile(new Position(2, 8), new IceTile(new Position(2, 8)));
        map.setTile(new Position(3, 8), new IceTile(new Position(3, 8)));
        map.setTile(new Position(4, 8), new IceTile(new Position(4, 8)));
        map.setTile(new Position(7, 8), new IceTile(new Position(7, 8)));
        map.setTile(new Position(8, 8), new IceTile(new Position(8, 8)));

        map.setTile(new Position(1, 7), new IceTile(new Position(1, 7)));
        map.setTile(new Position(2, 7), new IceTile(new Position(2, 7)));
        map.setTile(new Position(3, 7), new IceTile(new Position(3, 7)));
        map.setTile(new Position(4, 7), new IceTile(new Position(4, 7)));
        map.setTile(new Position(7, 7), new IceTile(new Position(7, 7)));
        map.setTile(new Position(8, 7), new IceTile(new Position(8, 7)));

        map.setTile(new Position(7, 6), new IceTile(new Position(7,6)));
        map.setTile(new Position(8, 6), new IceTile(new Position(8, 6)));

        map.setTile(new Position(7, 5), new IceTile(new Position(7,5)));
        map.setTile(new Position(8,5), new IceTile(new Position(8, 5)));

        map.setTile(new Position(2, 4), new IceTile(new Position(2,4)));
        map.setTile(new Position(3, 4), new IceTile(new Position(3, 4)));

        map.setTile(new Position(1, 3), new IceTile(new Position(1, 3)));
        map.setTile(new Position(2, 3), new IceTile(new Position(2,3)));
        map.setTile(new Position(3,3), new IceTile(new Position(3,3)));

        // Locked Doors
        map.setTile(new Position(5, 3), new RedDoorTile(new Position(5,3)));

        // Exit
        map.setTile(new Position(8, 1), new ExitTile(new Position(8,1)));

        // Enemy Entity (AngryTeeth)
        // Starts at (1,1) and patrols the map left to right
        map.setTile(new Position(1, 1), new AngryTeethTile(new Position(1, 1)));

        // Items
        map.setTile(new Position(3, 6), new Microchip(new Position(3,6)));
        map.setTile(new Position(1, 4), new Microchip(new Position(1,4)));
        map.setTile(new Position(8, 2), new Microchip(new Position(8,2)));

        map.setTile(new Position(8, 4), new RedKeyItem(new Position(8,4)));

        return map;
    }

    /**
     * Constructs and loads the layout for Level 4.
     * This level introduces Mud Tiles (slow movement) and Hiking Boots.
     * It serves as a final challenge combining various mechanics.
     * @return A Map object populated with Level 4 tiles and entities.
     */
    public static Map loadLevel4() {
        int width = 10, height = 10;
        Position start = new Position(8, 1);
        int chipsRequired = 3;
        
        Chip chip = new Chip(start);
        Map map = new Map(width, height, chip, chipsRequired);
        
        // Initialize floor
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                map.setTile(new Position(x, y), new FloorTile(new Position(x, y)));
            }
        }

        // Outer Walls
        for(int x = 0; x < width; x++){
            map.setTile(new Position(x, 0), new WallTile(new Position(x, 0))); 
            map.setTile(new Position(x, height-1), new WallTile(new Position(x, height-1))); 
        }

        for(int y = 0; y < height; y++){
            map.setTile(new Position(0, y), new WallTile(new Position(0, y))); 
            map.setTile(new Position(width-1, y), new WallTile(new Position(width-1, y))); 
        }

        // Interior Walls
        map.setTile(new Position(4, 1), new WallTile(new Position(4, 1)));
        map.setTile(new Position(5, 1), new WallTile(new Position(5, 1)));
        map.setTile(new Position(6, 1), new WallTile(new Position(6, 1)));
        map.setTile(new Position(7, 1), new WallTile(new Position(7, 1)));

        map.setTile(new Position(4, 2), new WallTile(new Position(4, 2)));

        map.setTile(new Position(4, 3), new WallTile(new Position(4, 3)));
        map.setTile(new Position(5, 3), new WallTile(new Position(5, 3)));
        map.setTile(new Position(6, 3), new WallTile(new Position(6, 3)));
        map.setTile(new Position(7, 3), new WallTile(new Position(7, 3)));

        map.setTile(new Position(1, 4), new WallTile(new Position(1, 4)));
        map.setTile(new Position(2, 4), new WallTile(new Position(2, 4)));
        map.setTile(new Position(4, 4), new WallTile(new Position(4, 4)));
        map.setTile(new Position(5, 4), new WallTile(new Position(5, 4)));

        map.setTile(new Position(1, 5), new WallTile(new Position(1, 5)));
        map.setTile(new Position(2, 5), new WallTile(new Position(2, 5)));
        map.setTile(new Position(4, 5), new WallTile(new Position(4, 5)));
        map.setTile(new Position(5, 5), new WallTile(new Position(5, 5)));

        map.setTile(new Position(4, 6), new WallTile(new Position(4, 6)));
        map.setTile(new Position(5, 6), new WallTile(new Position(5, 6)));

        map.setTile(new Position(1, 7), new WallTile(new Position(1, 7)));
        map.setTile(new Position(2, 7), new WallTile(new Position(2, 7)));
        map.setTile(new Position(4, 7), new WallTile(new Position(4, 7)));
        map.setTile(new Position(5, 7), new WallTile(new Position(5, 7)));

        // Mud Tiles 
        map.setTile(new Position(2, 1), new MudTile(new Position(2,1)));
        map.setTile(new Position(3, 1), new MudTile(new Position(3,1)));

        map.setTile(new Position(1, 2), new MudTile(new Position(1,2)));
        map.setTile(new Position(2, 2), new MudTile(new Position(2,2)));
        map.setTile(new Position(3, 2), new MudTile(new Position(3,2)));

        map.setTile(new Position(1, 3), new MudTile(new Position(1,3)));
        map.setTile(new Position(2, 3), new MudTile(new Position(2,3)));
        map.setTile(new Position(3, 3), new MudTile(new Position(3,3)));

        map.setTile(new Position(6, 4), new MudTile(new Position(6,4)));
        map.setTile(new Position(7, 4), new MudTile(new Position(7,4)));
        map.setTile(new Position(8, 4), new MudTile(new Position(8,4)));

        map.setTile(new Position(6, 5), new MudTile(new Position(6,5)));
        map.setTile(new Position(7, 5), new MudTile(new Position(7,5)));

        map.setTile(new Position(6, 6), new MudTile(new Position(6,6)));
        map.setTile(new Position(7, 6), new MudTile(new Position(7,6)));

        map.setTile(new Position(6, 7), new MudTile(new Position(6,7)));

        map.setTile(new Position(5, 8), new MudTile(new Position(5,8)));

        // Doors
        map.setTile(new Position(3, 7), new RedDoorTile(new Position(3,7)));
        map.setTile(new Position(8, 3), new BlueDoorTile(new Position(8,3)));

        // Exit
        map.setTile(new Position(1, 6), new ExitTile(new Position(1,6)));

        // Items
        map.setTile(new Position(1, 1), new Microchip(new Position(1, 1))); 
        map.setTile(new Position(5, 2), new Microchip(new Position(5, 2)));
        map.setTile(new Position(2, 8), new Microchip(new Position(2, 8)));

        map.setTile(new Position(1, 8), new RedKeyItem(new Position(1,8)));
        map.setTile(new Position(6, 2), new BlueKeyItem(new Position(6, 2)));
        map.setTile(new Position(8, 6), new HikingBootsItem(new Position(8,6)));

        return map;
    }
}