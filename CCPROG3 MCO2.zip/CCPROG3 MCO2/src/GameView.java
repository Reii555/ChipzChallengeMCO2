import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

/**
 * The primary visual component of the application.
 * This class extends the JavaFX Canvas and is responsible for rendering 
 * the game state (Map, Tiles, and Player) onto the screen. It utilizes 
 * an internal game loop (AnimationTimer) to handle real-time updates 
 * and drawing cycles.
 */
public class GameView extends Canvas {

    // The base resolution of a single tile in pixels (32x32).
    private static final int TILE_SIZE = 32;
    
    // The visual scaling factor. This magnifies the 32px tiles to make them
    // easier to see on modern high-resolution screens.
    private static final double SCALE = 2.5; 
    
    // Reference to the data model containing the grid and player state.
    private final Map map;

    // The JavaFX timer that acts as the "heartbeat" of the rendering loop.
    private AnimationTimer timer;
    
    // Tracking variables for the Exit portal animation.
    private int exitFrame = 0;
    private long lastExitUpdate = 0;

    // Tracking variables for the Player (Chip) animation.
    private int chipFrame = 0;
    private long lastChipUpdate = 0;

    /**
     * Initializes the game view, sets the window dimensions based on the map size,
     * and begins the rendering loop.
     * @param map The data model representing the game world to be rendered.
     */
    public GameView(Map map) {
        this.map = map;
        
        // Calculate the total canvas size: (Grid Dimensions * Tile Pixel Size * Scale Factor).
        this.setWidth(map.getWidth() * TILE_SIZE * SCALE);
        this.setHeight(map.getHeight() * TILE_SIZE * SCALE);

        // Ensure this canvas can receive keyboard focus (essential for input handling).
        this.setFocusTraversable(true);
        
        startAnimation();
    }

    /**
     * Instantiates and starts the AnimationTimer.
     * This creates a loop that runs roughly 60 times per second (depending on monitor refresh rate).
     * In every frame, it updates the internal animation counters and redraws the screen.
     */
    private void startAnimation() {
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                updateAnimations(now);
                draw();
            }
        };
        timer.start();
    }

    /**
     * Manages the timing logic for sprite animations.
     * This ensures that animations play at a consistent speed, regardless of the 
     * computer's frame rate. It also handles dynamic animation speeds, such as 
     * the player moving their feet faster on Ice or slower on Mud.
     * @param now The current timestamp in nanoseconds provided by the AnimationTimer.
     */
    private void updateAnimations(long now) {
        // Convert nanoseconds to milliseconds for easier calculation.
        long nowMs = now / 1_000_000;

        // Exit Portal Animation Logic 
        // Updates the flashing exit frame every 250ms (4 frames per second).
        if (nowMs - lastExitUpdate >= 250) {
            exitFrame++;
            lastExitUpdate = nowMs;
        }

        // Chip (Player) Animation Speed Control 
        long chipDelay = 250; // Default: Normal speed (4 FPS)

        // Check if the player exists and adjust animation speed based on terrain.
        if (map.getChip() != null) {
            Tile currentTile = map.getTileAt(map.getChip().getPosition().getX(), map.getChip().getPosition().getY());
            
            if (currentTile instanceof MudTile) {
                chipDelay = 333; // Slow animation: Mud (3 FPS)
            } else if (currentTile instanceof IceTile) {
                chipDelay = 166; // Fast animation: Ice (6 FPS)
            }
        }

        // Continuous Animation Update 
        // If enough time has passed based on the calculated delay, advance the animation frame.
        if (nowMs - lastChipUpdate >= chipDelay) {
            chipFrame++;
            lastChipUpdate = nowMs;
        }
    }

    /**
     * The main rendering method.
     * Clears the canvas and repaints the entire game state frame-by-frame.
     * The drawing order is critical: Background -> Floor -> Objects -> Player.
     */
    public void draw() {
        GraphicsContext gc = this.getGraphicsContext2D();
        
        // 1. Clear the screen with a black background.
        gc.setFill(Color.BLACK);
        gc.fillRect(0, 0, getWidth(), getHeight());
        
        // Disable smoothing to keep the pixel art looking crisp 
        gc.setImageSmoothing(false);

        // 2. Iterate through every coordinate in the map grid.
        for (int y = 0; y < map.getHeight(); y++) {
            for (int x = 0; x < map.getWidth(); x++) {
                Tile tile = map.getTileAt(x, y);
                
                // Always draw a floor tile first to serve as the background for the cell.
                drawTile(gc, SpriteLoader.getFloor(), x, y);
                
                // If a specific tile object exists here (Wall, Key, Door, etc.), draw it on top.
                if (tile != null) {
                    Image img = getImageForTile(tile);
                    if (img != null) drawTile(gc, img, x, y);
                }
            }
        }

        // 3. Draw the Player (Chip) last so they appear on top of all other tiles.
        Chip chip = map.getChip();
        if (chip != null) {
            // Retrieve the correct sprite based on direction and current animation frame.
            Image chipImg = SpriteLoader.getChip(chip.getLastMoveDirection(), chipFrame); 
            Position pos = chip.getPosition(); 
            drawTile(gc, chipImg, pos.getX(), pos.getY());
        }
    }

    /**
     * A helper method to render a single image at a specific grid coordinate.
     * Handles the mathematical conversion from Grid Coordinates (0, 1, 2) 
     * to Pixel Coordinates (0, 80, 160) taking the scale factor into account.
     * @param gc  The GraphicsContext used for drawing.
     * @param img The visual image to draw.
     * @param x   The X-coordinate on the map grid.
     * @param y   The Y-coordinate on the map grid.
     */
    private void drawTile(GraphicsContext gc, Image img, int x, int y) {
        gc.drawImage(img, x * TILE_SIZE * SCALE, y * TILE_SIZE * SCALE, TILE_SIZE * SCALE, TILE_SIZE * SCALE);
    }

    /**
     * Determines the correct visual asset for a given logical Tile object.
     * This acts as a registry, mapping backend logic classes (e.g., WallTile) 
     * to frontend assets (e.g., wall.png).
     * @param t The Tile object being rendered.
     * @return The corresponding Image object, or null if no image is found.
     */
    private Image getImageForTile(Tile t) {
        if (t instanceof WallTile) return SpriteLoader.getWall();
        if (t instanceof FloorTile) return SpriteLoader.getFloor();
        if (t instanceof WaterTile) return SpriteLoader.getWater();
        if (t instanceof IceTile)   return SpriteLoader.getIce();
        if (t instanceof FireTile)  return SpriteLoader.getFire();
        if (t instanceof MudTile)   return SpriteLoader.getMud();
        
        // Exit tiles change appearance based on the animation frame.
        if (t instanceof ExitTile)  return SpriteLoader.getExitFrame(exitFrame);
        
        // Force floors need to visually indicate the direction they push.
        if (t instanceof ForceFloor) return SpriteLoader.getForceFloor(((ForceFloor) t).getForceDirection());
        
        // Enemies 
        if (t instanceof AngryTeethTile) return SpriteLoader.getEnemy(Direction.DOWN);

        // Collectibles and Interactables
        if (t instanceof Microchip)     return SpriteLoader.getMicrochip();
        if (t instanceof RedKeyItem)    return SpriteLoader.getRedKey();
        if (t instanceof BlueKeyItem)   return SpriteLoader.getBlueKey();
        if (t instanceof RedDoorTile)   return SpriteLoader.getRedDoor();
        if (t instanceof BlueDoorTile)  return SpriteLoader.getBlueDoor();
        if (t instanceof FlipperItem)   return SpriteLoader.getFlippers();
        if (t instanceof FireBootsItem) return SpriteLoader.getFireBoots();
        if (t instanceof HikingBootsItem) return SpriteLoader.getHikingBoots();

        return null;
    }
}