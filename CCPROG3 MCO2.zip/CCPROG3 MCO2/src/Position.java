/**
 * Represents a specific coordinate (x, y) on the 2D game grid.
 * This class is used to track the location of tiles, items, and actors within the map.
 */
public class Position {
    private int x;
    private int y;

    /**
     * Creates a new Position object at the specified coordinates.
     * @param x The x-coordinate (column index).
     * @param y The y-coordinate (row index).
     */
    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Retrieves the x-coordinate of this position.
     * @return The current x value.
     */
    public int getX() {
        return x;
    }

    /**
     * Retrieves the y-coordinate of this position.
     * @return The current y value.
     */
    public int getY() {
        return y;
    }

    /**
     * Updates the x-coordinate of this position.
     * @param x The new x value to set.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Updates the y-coordinate of this position.
     * @param y The new y value to set.
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Calculates the adjacent position based on the given direction.
     * Note: This method returns a NEW Position object and does not modify the current instance.
     * @param direction The cardinal direction to move towards (UP, DOWN, LEFT, RIGHT).
     * @return A new Position object representing the target coordinates.
     */
    public Position move(Direction direction) {
        switch (direction) {
            case UP:    return new Position(x, y - 1);
            case DOWN:  return new Position(x, y + 1);
            case LEFT:  return new Position(x - 1, y);
            case RIGHT: return new Position(x + 1, y);
            default:    return this; // Return current position if direction is NONE
        }
    }

    /**
     * Returns a string representation of the position in the format "(x, y)".
     * Useful for debugging logs and console output.
     * @return The string representation of the coordinates.
     */
    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
    
}