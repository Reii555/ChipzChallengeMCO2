/**
 * Represents an Ice tile within the game map. 
 * This tile introduces a sliding mechanic: when the Chip entity enters this tile, 
 * it is forced to continue moving in its previous direction without friction 
 * until it reaches a non-ice tile or an obstacle.
 */
public class IceTile extends Tile {

    /**
     * Constructs a new instance of an IceTile at the specified position.
     * @param position The coordinate location of this tile within the game grid.
     */
    public IceTile(Position position) {
        super(position);
    }

    /**
     * Determines if the provided Chip entity is allowed to enter this tile.
     * Ice tiles are inherently passable, effectively acting as open floor 
     * before the sliding physics are applied.
     * @param c The Chip entity attempting to enter the tile.
     * @return {@code true} as the tile is always traversable.
     */
    @Override
    public boolean isPassable(Chip c) {
        return true; 
    }

    /**
     * Triggered immediately when the Chip entity enters this tile.
     * This method implements the core ice behavior. It retrieves the direction 
     * the Chip was traveling when it stepped onto the tile and requests a 
     * forced movement (slide) in that same direction from the Map controller.
     * @param map  The current game map instance, used to request forced movement.
     * @param chip The Chip entity currently occupying the tile.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // Standard Ice Behavior: Keep sliding in the same direction
        Direction dir = chip.getLastMoveDirection();
        
        // If the chip appeared here without movement (e.g., teleport or spawn), do not slide.
        if (dir == null) return;

        int dx = 0, dy = 0;
        switch (dir) {
            case UP:    dy = -1; break;
            case DOWN:  dy = 1; break;
            case LEFT:  dx = -1; break;
            case RIGHT: dx = 1; break;
            default: return;
        }

        // Request the map to force the chip to move again in the calculated direction
        map.requestForce(dx, dy);
    }

    /**
     * Retrieves the string identifier for this specific tile type.
     * This identifier is typically used for level parsing, serialization, or debugging.
     * @return The string literal "IceTile".
     */
    @Override
    public String getTileType() { return "IceTile"; }

    /**
     * Retrieves the visual key used by the renderer to draw this tile.
     * The GUI system uses this string to map the tile logic to the correct 
     * sprite or texture asset (e.g., an image of ice).
     * @return The string literal "Ice".
     */
    @Override
    public String getVisualState() { return "Ice"; }
}