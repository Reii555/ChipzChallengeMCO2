/**
 * Represents a solid wall tile that acts as an impassable barrier in the game.
 * Players and enemies cannot move onto or through this tile type.
 */
public class WallTile extends Tile {

    /**
     * Creates a new Wall tile at the specified position.
     * @param position The grid coordinates for this wall.
     */
    public WallTile(Position position) {
        super(position);
    }

    /**
     * Determines if the player (Chip) can step onto this tile.
     * Walls are solid obstacles, so this always returns false to block movement.
     * @param c The Chip instance attempting to enter.
     * @return false, effectively blocking the player.
     */
    @Override
    public boolean isPassable(Chip c) {
        return false; // Wall tiles are always impassable
    }

    /**
     * Handles the logic when the player enters this tile.
     * Since walls are impassable, this method is technically unreachable during standard movement.
     * @param map The current game map.
     * @param chip The player character.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // No action needed since walls cannot be entered
    }

    /**
     * Returns the string identifier for this tile type.
     * Used by the GUI or saving mechanisms to identify the tile.
     * @return "Wall"
     */
    @Override
    public String getTileType(){
        return "Wall";
    }

    /**
     * Returns the visual state string for rendering logic.
     * @return "Solid"
     */
    @Override
    public String getVisualState(){
        return "Solid";
    }

}