public class RedDoorTile extends DoorTile {
    /**
     * Constructs a new Red Door tile at the specified position.
     * Initializes the door with the "red" color attribute and sets the
     * corresponding visual assets required by the GameView.
     * @param position The grid coordinates where this door is located.
     */
    public RedDoorTile(Position position) {
        super(position, "red", "RedDoorTile", "red_door");
    }

    /**
     * Determines if the player is permitted to enter this tile.
     * The Red Door is acting as a solid wall unless the player's inventory
     * currently contains a Red Key.
     * @param c The instance of the player character (Chip).
     * @return true if the player has a Red Key; false otherwise.
     */
    @Override
    public boolean isPassable(Chip c) {
        return c.getInventory().hasRedKey();
    }

    /**
     * Executes the logic when the player successfully steps onto the door.
     * If the player enters this tile (which implies isPassable returned true),
     * this method consumes one Red Key from the player's inventory and permanently
     * removes the door tile from the map, effectively "opening" it.
     * @param map The current game map context.
     * @param chip The player character triggering the event.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        if (chip != null && chip.getInventory().hasRedKey()) {
            chip.getInventory().useRedKey();
            map.removeTile(this.getPosition()); // Remove door after opening
        }
    }

}