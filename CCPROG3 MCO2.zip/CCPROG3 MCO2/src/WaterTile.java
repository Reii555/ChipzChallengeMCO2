/**
 * Represents a Water tile within the game map.
 * This tile acts as a lethal hazard. If the player attempts to step onto this tile 
 * without the appropriate gear ("Flippers"), they will instantly drown, resulting 
 * in the loss of a life or game over.
 */
public class WaterTile extends Tile {

    /**
     * Constructs a new WaterTile instance at the specified coordinate.
     * @param position The (x, y) coordinate location where this water hazard is placed.
     */
    public WaterTile(Position position) {
        super(position);
    }

    /**
     * Determines whether the player (Chip) is physically allowed to step onto this tile.
     * Note: This method purposely returns `true` even though the tile is dangerous.
     * In Chip's Challenge logic, hazards like water or fire are considered "passable" 
     * so that the player actually enters the cell to trigger the death condition.
     * @param c The Chip (player) entity attempting to move.
     * @return true, allowing the player to enter the tile (and potentially drown).
     */
    @Override
    public boolean isPassable(Chip c) {
        // MUST return true so Chip enters the tile and the onEnter() logic triggers.
        return true; 
    }

    /**
     * Executed immediately when the player (Chip) enters this tile.
     * This method contains the core logic for the water hazard:
     * 1. Checks the player's inventory for "Flippers".
     * 2. If flippers are missing, the player drowns immediately.
     * 3. If flippers are present, the player survives and stands on the water.
     * @param map  The current instance of the game map.
     * @param chip The player entity triggering the interaction.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        Inventory inv = chip.getInventory();
        
        // Instant Death Logic check
        // If the player does not have the ability to swim (Flippers), execute death sequence.
        if (!inv.canSwim()) {
            chip.die(); // Sets health to 0 or triggers level reset
            System.out.println("Drowned! Chip died.");
        }
    }

    /**
     * Retrieves the unique identifier for this class of tile.
     * Used for game logic or serialization to identify this specific hazard type.
     * @return The string identifier "WaterTile".
     */
    @Override
    public String getTileType(){ 
        return "WaterTile"; 
    }

    /**
     * Retrieves the visual key associated with this tile.
     * The renderer uses this string to map the logical tile to the correct 
     * blue water sprite or animation frame.
     * @return The string key "water".
     */
    @Override
    public String getVisualState(){ 
        return "water"; 
    }
}