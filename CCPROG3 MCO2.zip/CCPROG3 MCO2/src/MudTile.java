/**
 * Represents a Mud tile within the game map.
 * This tile introduces a sliding mechanic: if the player does not possess 
 * the specific "Mud Boots" inventory item, they will slip and continue 
 * moving in their current direction without stopping.
 */
public class MudTile extends Tile {

    /**
     * Constructs a new MudTile instance at the specified coordinate.
     * @param position The (x, y) coordinate location where this tile is placed on the map.
     */
    public MudTile(Position position) {
        super(position);
    }

    /**
     * Determines whether the player (Chip) is physically allowed to step onto this tile.
     * Mud tiles are inherently passable surfaces, meaning they do not block movement 
     * like a wall, regardless of the player's inventory.
     * @param c The Chip (player) entity attempting to move.
     * @return true, as Mud is always accessible.
     */
    @Override
    public boolean isPassable(Chip c) {
        return true; 
    }

    /**
     * Executed immediately when the player (Chip) successfully enters this tile.
     * This method contains the logic for the mud's sliding mechanic. It checks the 
     * player's inventory for "Mud Boots." If the boots are missing, the player 
     * interacts with the mud as a slippery surface and is forced to slide.
     * @param map  The current instance of the game map, used to apply forced movement.
     * @param chip The player entity triggering the interaction.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // If the player is equipped with boots, the mud behaves like a standard floor,
        // allowing the player to stop or change direction freely.
        if (chip.getInventory().canWalkOnMud()) {
            return;
        }

        // If no boots are present, initiate the sliding mechanic.
        // We retrieve the direction the player was traveling when they entered the tile.
        Direction dir = chip.getLastMoveDirection();
        
        // Safety check: If for some reason there is no movement history, do nothing.
        if (dir == null) return;

        // Convert the directional enum into x/y coordinate modifiers
        // to determine where the force should be applied.
        int dx = 0, dy = 0;
        switch (dir) {
            case UP:    dy = -1; break;
            case DOWN:  dy = 1; break;
            case LEFT:  dx = -1; break;
            case RIGHT: dx = 1; break;
            default: return;
        }

        // Request a forced move from the Map controller in the continuing direction.
        map.requestForce(dx, dy);
    }

    /**
     * Retrieves the unique identifier for this class of tile.
     * This is typically used for serialization or game logic that needs to 
     * distinguish between tile types programmatically.
     * @return The string identifier "MudTile".
     */
    @Override
    public String getTileType() { 
        return "MudTile"; 
    }

    /**
     * Retrieves the visual key associated with this tile.
     * The renderer uses this string to determine which sprite or texture 
     * to draw on the screen (e.g., a brown mud graphic).
     * @return The string key "Mud".
     */
    @Override
    public String getVisualState() { 
        return "Mud"; 
    }
}