/**
 * An abstract base class representing a Door tile on the game map.
 * Doors are fixed obstacles that require a corresponding key (Red or Blue) to be opened.
 * This class handles the common properties for all colored doors.
 */
public abstract class DoorTile extends Tile {
    private String doorColor;
    private String tileType;
    private String visualState;

   /**
    * Creates a new DoorTile instance.
    * @param position The grid coordinates for the door.
    * @param doorColor A string identifier for the color of the door (e.g., "Red", "Blue").
    * @param tileType A string representing the class type (e.g., "RedDoorTile").
    * @param visualState A string representing the visual state (e.g., "redDoor", "blueDoor").
    */
   public DoorTile(Position position, String doorColor, String tileType, String visualState) {
        super(position);
        this.doorColor = doorColor;
        this.tileType = tileType;
        this.visualState = visualState;
    }

   /**
    * Abstract method to determine if the player can pass through this door.
    * The implementing subclass (e.g., RedDoorTile) must check the player's inventory for the correct key.
    * @param c The Chip instance attempting to enter.
    * @return true if the player has the required key and the door is passable; false otherwise.
    */
   public abstract boolean isPassable(Chip c);
   
   /**
    * Abstract method to define the action that occurs when the player successfully enters and opens the door.
    * This typically involves consuming the key and removing the door from the map.
    * @param map The current game map.
    * @param chip The player character.
    */
   public abstract void onEnter(Map map, Chip chip);

    /**
     * Retrieves the state of the door, used for inventory management and visual checks.
     * @return A string combining the door color and state, e.g., "Red_door".
     */
    public String getDoorState(){
        return doorColor + "_door";
    }

    /**
     * Returns the string identifier for this tile's specific class type.
     * @return The specific tile type string (e.g., "RedDoorTile").
     */
    @Override
    public String getTileType() {
        return tileType;
    }

    /**
     * Returns the visual state string for rendering purposes (used by the SpriteLoader).
     * @return The string representing the visual asset (e.g., "redDoor").
     */
    @Override
    public String getVisualState() {
        return visualState;
    }

}