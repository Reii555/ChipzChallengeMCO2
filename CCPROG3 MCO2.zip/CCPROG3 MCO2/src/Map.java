/**
 * Represents the game grid and acts as the central controller for game logic.
 * This class manages the state of the board, the position of the player (Chip),
 * and handles the interaction between the player and the tiles (movement, collisions,
 * and triggered events like sliding).
 */
public class Map {

    private final int width, height;
    private final Tile[][] tiles; 
    private final Chip chip; 
    
    // Level Objective State
    private final int chipsRequired; 
    private int chipsCollected; 
    private boolean nextLevelRequested = false; 
    
    // Force Movement State (Used for Ice/Force floor physics)
    private int forceDx = 0, forceDy = 0; 

    /**
     * Initializes a new Map with specific dimensions and objective requirements.
     * Note: The tiles array is initialized here but remains empty until 
     * populated by the LevelParser.
     *
     * @param width         The width of the game grid (x-axis).
     * @param height        The height of the game grid (y-axis).
     * @param chip          The player entity instance.
     * @param chipsRequired The total number of computer chips needed to finish the level.
     */
    public Map(int width, int height, Chip chip, int chipsRequired) {
        this.width = width; 
        this.height = height;
        this.chip = chip; 
        this.chipsRequired = chipsRequired;
        this.chipsCollected = 0;
        this.tiles = new Tile[height][width];
    }

    /**
     * Attempts to move the Chip entity based on user input.
     * <p>
     * This method validates the move against grid boundaries and tile passability.
     * If valid, it updates the Chip's position and triggers the onEnter
     * event of the target tile.
     *
     * @param targetX The target X coordinate.
     * @param targetY The target Y coordinate.
     * @return true if the move was successful; false if blocked or out of bounds.
     */
    public boolean moveChip(int targetX, int targetY){
        if(!inBounds(targetX, targetY)) return false; 

        Tile target = getTileAt(targetX, targetY);
        // Check if the tile exists and if the specific tile logic allows the chip to enter
        if (target == null || !target.isPassable(chip)) return false;

        // Valid move: Update state
        updateLastMoveDirection(targetX, targetY);
        chip.setPosition(new Position(targetX, targetY));
        
        // Trigger tile interactions (e.g., collecting items, stepping on ice)
        target.onEnter(this, chip);

        return true;
    }

    /**
     * Executes a single step of forced movement (sliding).
     * This is typically called by the GameLoop on every frame. It checks if an 
     * IceTile or ForceFloor has requested momentum. If so, it moves 
     * the chip automatically without user input.
     * * @return true if a forced move occurred; false if the chip is stationary.
     */
    public boolean updateForceMovement() {
        if (!hasForce()) return false;

        int tx = chip.getPosition().getX() + forceDx;
        int ty = chip.getPosition().getY() + forceDy;
        
        // IMPORTANT: Capture the current force to apply it, then immediately reset the 
        // global force variables. This prevents infinite loops if the next tile 
        // is a standard FloorTile (which adds no new force).
        int currentDx = forceDx;
        int currentDy = forceDy;
        forceDx = 0; 
        forceDy = 0;

        // Check for collisions (Walls or bounds) during the slide
        if(!inBounds(tx, ty) || !getTileAt(tx, ty).isPassable(chip)) {
            return false;
        }

        // Apply the slide movement
        updateLastMoveDirection(tx, ty);
        chip.setPosition(new Position(tx, ty));
        
        // Trigger the next tile's event. If it is also Ice, it will call 
        // requestForce() again, chaining the movement.
        getTileAt(tx, ty).onEnter(this, chip);
        
        return true;
    }

    /**
     * Checks if there is currently a forced movement vector applied to the Chip.
     * @return true if the chip is currently sliding or being pushed.
     */
    public boolean hasForce(){ return forceDx != 0 || forceDy != 0; }
    
    /**
     * Queues a forced movement vector to be applied on the next game update.
     * This is typically called by tiles like IceTile inside their 
     * onEnter method.
     *
     * @param dx The delta X force (horizontal momentum).
     * @param dy The delta Y force (vertical momentum).
     */
    public void requestForce(int dx, int dy){ 
        forceDx = dx; forceDy = dy; 
    }
    
    /**
     * Cancels any pending forced movement. 
     * Useful for tiles that stop momentum, like Gravel or Dirt.
     */
    public void clearForce() {
        forceDx = 0; forceDy = 0;
    }

    // GETTERS & HELPERS 

    /**
     * Helper method to calculate and update the Direction enum 
     * based on the difference between the current position and the target position.
     * @param targetX The X coordinate the chip just moved to.
     * @param targetY The Y coordinate the chip just moved to.
     */
    private void updateLastMoveDirection(int targetX, int targetY){
        Position current = chip.getPosition();
        if(targetX > current.getX()) chip.setLastMoveDirection(Direction.RIGHT);
        else if(targetX < current.getX()) chip.setLastMoveDirection(Direction.LEFT);
        else if(targetY > current.getY()) chip.setLastMoveDirection(Direction.DOWN);
        else if(targetY < current.getY()) chip.setLastMoveDirection(Direction.UP);
    }

    public int getWidth(){ return width; }
    public int getHeight(){ return height; }
    public Chip getChip(){ return chip; }
    public int getChipsCollected(){ return chipsCollected; }
    public int getChipsRequired(){ return chipsRequired; }
    
    /**
     * Checks if the user has collected enough chips to pass the level.
     * @return true if the collected amount meets or exceeds the requirement.
     */
    public boolean isLevelCompleted(){ return chipsCollected >= chipsRequired; }
    
    /**
     * Flags the system that the level has been beaten and the next stage should load.
     * Usually called by the PortalTile.
     */
    public void requestNextLevel(){ nextLevelRequested = true; }

    /**
     * Checks and consumes the next level request flag.
     * This method resets the flag to false after reading it to ensure 
     * the level transition logic runs only once per request.
     * @return true if a request was pending.
     */
    public boolean takeNextLevelRequest() {
        boolean v = nextLevelRequested; 
        nextLevelRequested = false; 
        return v;
    }

    /**
     * Validates if a coordinate set is within the map dimensions.
     * @param x The X coordinate.
     * @param y The Y coordinate.
     * @return true if the coordinates are valid.
     */
    public boolean inBounds(int x, int y){ return x>=0 && y>=0 && x<width && y<height; }

    /**
     * Safely retrieves a Tile object at specific coordinates.
     * @param x The X coordinate.
     * @param y The Y coordinate.
     * @return The Tile object, or null if out of bounds.
     */
    public Tile getTileAt(int x, int y){ 
        return (!inBounds(x, y)) ? null : tiles[y][x]; 
    }

    /**
     * Places a specific tile object into the grid at the given position.
     * @param pos The position object containing coordinates.
     * @param t   The tile instance to place.
     */
    public void setTile(Position pos, Tile t){ tiles[pos.getY()][pos.getX()] = t; }
    
    /**
     * Effectively removes a tile by replacing it with a standard FloorTile.
     * This is used when an interactive tile (like a Key or Chip) is collected.
     * @param pos The position of the tile to remove.
     * @return true if the tile was successfully replaced.
     */
    public boolean removeTile(Position pos) {
        if (!inBounds(pos.getX(), pos.getY())) return false;
        setTile(pos, new FloorTile(pos));
        return true;
    }

    public void incrementChipsCollected(){ chipsCollected++; }
}