/**
 * Represents a hazardous Fire tile in the game map.
 * This tile acts as a deadly obstacle. Unlike walls, it does not block movement; 
 * instead, it allows the player to enter and then immediately kills them unless 
 * they possess the specific protection item (Fire Boots).
 */
public class FireTile extends Tile {

    /**
     * Constructs a new FireTile at the specified grid position.
     * * @param position The coordinate location of this tile within the game grid.
     */
    public FireTile(Position position) {
        super(position);
    }

    /**
     * Determines if the Chip entity can enter this tile.
     * This method intentionally returns true regardless of the player's 
     * inventory. This ensures the player actually steps *into* the fire 
     * (triggering the onEnter death logic) rather than harmlessly 
     * bumping against it like a wall.
     * * @param c The Chip entity attempting to move.
     * @return true always, allowing entry into the hazard.
     */
    @Override
    public boolean isPassable(Chip c) {
        // MUST return true so Chip enters the tile and burns
        return true; 
    }

    /**
     * Triggered immediately when the Chip entity steps onto this tile.
     * This method enforces the hazard logic:
     * 1. It checks the player's inventory for "Fire Boots".
     * 2. If the boots are missing, it triggers the player's death sequence.
     * 3. If the boots are present, the tile acts as safe, walkable floor.
     * @param map  The current game map controller.
     * @param chip The Chip entity occupying the tile.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        Inventory inv = chip.getInventory();
        
        // Check for protection. If the player lacks Fire Boots, kill them.
        if (!inv.canWalkOnFire()) {
            chip.die(); // Health goes to 0 immediately, triggering Game Over logic elsewhere
            System.out.println("Burned! Chip died.");
        }
    }

    /**
     * Retrieves the string identifier for this specific tile type.
     * Used for saving/loading levels or internal logic differentiation.
     * @return The string literal "FireTile".
     */
    @Override 
    public String getTileType(){ return "FireTile"; }

    /**
     * Retrieves the visual key used by the renderer to draw this tile.
     * The GUI system uses this to map the tile to the "fire" sprite or animation.
     * @return The string literal "Fire".
     */
    @Override
    public String getVisualState(){ return "Fire"; }
}