/**
 * Represents a hostile enemy entity ("Angry Teeth") that patrols the map.
 * This tile acts as both an obstacle and a hazard. It moves automatically
 * in a straight line, reverses direction upon hitting obstacles, and deals
 * damage to the player upon contact.
 */
public class AngryTeethTile extends Tile {

    // The current facing and movement direction of the enemy.
    // Defaults to RIGHT to ensure horizontal patrolling in corridors.
    private Direction direction = Direction.RIGHT; 
    
    // Flag to prevent the enemy from moving multiple times within a single game tick.
    public boolean hasMoved = false; 

    /**
     * Constructs a new AngryTeeth enemy at the specified position.
     * @param position The initial grid coordinates for this enemy.
     */
    public AngryTeethTile(Position position) {
        super(position);
    }

    /**
     * Determines if the player can step onto this tile.
     * Returns true to allow the "collision" event to occur in onEnter().
     * @param c The Chip instance attempting to enter.
     * @return true, as the player must technically enter the tile to trigger damage.
     */
    @Override
    public boolean isPassable(Chip c) {
        return true; 
    }

    /**
     * Handles the event when the player walks into this enemy.
     * The player takes damage and is immediately pushed back to their previous position,
     * creating a "bounce" or "knockback" effect.
     * @param map  The current game map.
     * @param chip The player character.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // 1. Deal damage to the player
        chip.takeDmg(1); 
        System.out.println("Ouch! Enemy bit you. Lives: " + chip.getHealth());

        // 2. Calculate Knockback (Push Chip back to where he came from)
        Direction comingFrom = chip.getLastMoveDirection();
        int pushX = 0, pushY = 0;

        if (comingFrom == Direction.UP) pushY = 1;
        else if (comingFrom == Direction.DOWN) pushY = -1;
        else if (comingFrom == Direction.LEFT) pushX = 1;
        else if (comingFrom == Direction.RIGHT) pushX = -1;

        // 3. Apply the force immediately
        map.requestForce(pushX, pushY);
    }
    
    /**
     * Executes the enemy's AI movement logic.
     * The enemy moves in its current direction until blocked by a non-floor tile
     * (like a Wall or Door), at which point it reverses direction.
     * @param map The map instance, required to check for obstacles and update tile positions.
     */
    public void enemyMovement(Map map) {
        if (hasMoved) return; // Ensure we only move once per update cycle

        int dx = 0, dy = 0;
        switch (direction) {
            case UP:    dy = -1; break;
            case DOWN:  dy = 1; break;
            case LEFT:  dx = -1; break;
            case RIGHT: dx = 1; break;
            default: break;
        }

        int targetX = this.getPosition().getX() + dx;
        int targetY = this.getPosition().getY() + dy;

        // 1. Check Map Boundaries
        if (!map.inBounds(targetX, targetY)) {
            reverseDirection();
            return;
        }

        Tile targetTile = map.getTileAt(targetX, targetY);

        // 2. Check Obstacles
        // The enemy can only move onto empty Floor tiles.
        boolean canMove = (targetTile instanceof FloorTile);
        
        // 3. Check Attack Opportunity
        // If the player is standing on the target tile (even if it's not a FloorTile),
        // the enemy moves there to attack.
        Chip chip = map.getChip();
        if (chip.getPosition().getX() == targetX && chip.getPosition().getY() == targetY) {
            canMove = true;
        }

        if (canMove) {
            // A. Move Logic: Replace current position with a FloorTile
            map.setTile(this.getPosition(), new FloorTile(this.getPosition()));

            // B. Update internal position
            this.setPosition(new Position(targetX, targetY));
            this.hasMoved = true;

            // C. Place this enemy object at the new position on the map
            map.setTile(this.getPosition(), this);
        } else {
            // D. Blocked Logic: Turn around
            reverseDirection();
        }
    }

    /**
     * Reverses the enemy's current facing direction.
     * Used when the enemy hits a wall or map boundary.
     */
    private void reverseDirection() {
        switch (direction) {
            case UP:    direction = Direction.DOWN; break;
            case DOWN:  direction = Direction.UP; break;
            case LEFT:  direction = Direction.RIGHT; break;
            case RIGHT: direction = Direction.LEFT; break;
            default: break;
        }
    }

    /**
     * Gets the direction this enemy is currently facing.
     * Used by the renderer to select the correct sprite.
     * @return The current Direction enum value.
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * Sets the direction for this enemy.
     * @param d The new direction to face.
     */
    public void setDirection(Direction d) {
        this.direction = d;
    }

    /**
     * Returns the string identifier for this tile type.
     * @return "AngryTeethTile"
     */
    @Override
    public String getTileType(){ 
        return "AngryTeethTile"; 
    }

    /**
     * Returns the visual state string for rendering logic.
     * @return "enemy"
     */
    @Override
    public String getVisualState(){ 
        return "enemy"; 
    }
}