import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.util.HashSet;
import java.util.Set;

/**
 * The primary entry point for the Chip's Challenge application.
 * This class extends the JavaFX Application class and manages the
 * primary game loop, scene transitions, user input handling, and the
 * high-level game state (such as loading levels, pausing, and game-over sequences).
 */
public class Main extends Application {

    private static final int TOTAL_LEVELS = 4;
    private Map map;
    private int currentLevel = 1;
    private boolean gameRunning = true;
    private GameView gameView;
    private GameHUD gameHUD;
    private BorderPane root; 
    private Stage primaryStage; 
    private MediaPlayer mediaPlayer;
    private AnimationTimer gameLoop;
    private long lastMoveTime = 0; 
    private Set<KeyCode> activeKeys = new HashSet<>();

    /**
     * Initializes the JavaFX application stage and sets up the primary scene.
     * This method configures input listeners for keyboard interactions and
     * initiates the background music and game loop.
     * @param primaryStage The primary window (Stage) provided by the JavaFX runtime.
     */
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        SpriteLoader.initialize();
        root = new BorderPane();
        loadLevel(1);
        Scene scene = new Scene(root);
        
        // Track currently pressed keys to handle continuous movement or combinations
        scene.setOnKeyPressed(event -> activeKeys.add(event.getCode()));
        scene.setOnKeyReleased(event -> activeKeys.remove(event.getCode()));
        
        // Ensure the game view regains focus if the user clicks the window
        scene.setOnMouseClicked(event -> gameView.requestFocus());

        primaryStage.setTitle("Chip's Challenge - MCO2");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
        
        gameView.requestFocus();
        root.requestFocus();
        playBackgroundMusic();
        startGameLoop();
    }

    /**
     * Starts the main game loop using a JavaFX AnimationTimer.
     * This loop runs repeatedly (approx. 60 FPS) to update game logic and redraw the canvas.
     */
    private void startGameLoop() {
        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (!gameRunning || map == null) return;
                updateGame(now);
                gameView.draw(); 
            }
        };
        gameLoop.start();
    }

    /**
     * Executes the core game logic for a single frame.
     * This includes calculating movement speed based on terrain (e.g., Mud),
     * processing player input, and handling automatic movements (Force floors).
     * @param now The current timestamp of the frame in nanoseconds.
     */
    private void updateGame(long now) {
        long nowMs = now / 1_000_000;

        // 1. DETERMINE SPEED BASED ON TILE
        long moveDelay = 250; // Default speed (4 tiles/sec)
        
        Tile currentTile = map.getTileAt(map.getChip().getPosition().getX(), map.getChip().getPosition().getY());
        if (currentTile instanceof MudTile) {
            // If the player does not have boots, movement is slowed in mud
            if (!map.getChip().getInventory().canWalkOnMud()) {
                moveDelay = 500; // Mud speed (2 tiles/sec)
            }
        }

        // Throttle movement based on the calculated delay
        if (nowMs - lastMoveTime < moveDelay) return;

        // 2. CHECK PLAYER INPUT (INTERRUPT)
        int dx = 0, dy = 0;
        if (activeKeys.contains(KeyCode.UP) || activeKeys.contains(KeyCode.W)) dy = -1;
        else if (activeKeys.contains(KeyCode.DOWN) || activeKeys.contains(KeyCode.S)) dy = 1;
        else if (activeKeys.contains(KeyCode.LEFT) || activeKeys.contains(KeyCode.A)) dx = -1;
        else if (activeKeys.contains(KeyCode.RIGHT) || activeKeys.contains(KeyCode.D)) dx = 1;
        else if (activeKeys.contains(KeyCode.ESCAPE)) {
            activeKeys.clear(); 
            showPauseMenu();
            return;
        }

        // If Input Detected, interrupt any sliding/force and Move
        if (dx != 0 || dy != 0) {
            map.clearForce(); // Stop any auto-sliding
            boolean moved = map.moveChip(map.getChip().getPosition().getX() + dx, map.getChip().getPosition().getY() + dy);
            if (moved) {
                lastMoveTime = nowMs;
                postMoveLogic();
            }
            return; // Skip automatic sliding processing for this frame
        }

        // 3. CHECK AUTOMATIC SLIDING (Force Floors / Ice)
        if (map.hasForce()) {
            boolean moved = map.updateForceMovement();
            if (moved) {
                lastMoveTime = nowMs;
                postMoveLogic();
            }
        }
    }

    /**
     * handling logic that must occur immediately after the player moves.
     * This includes checking for hazards, updating enemy AI, and refreshing the HUD.
     */
    private void postMoveLogic() {
        checkPlayerDamage();
        if (gameRunning) updateEnemies();
        gameHUD.update();
        checkGameStatus();
    }

    /**
     * Resets the game state and loads the map data for the specified level.
     * @param level The integer identifier of the level to load (e.g., 1, 2, 3).
     */
    private void loadLevel(int level) {
        currentLevel = level;
        gameRunning = true; 
        activeKeys.clear(); 
        switch (level) {
            case 1: map = LevelLoader.loadLevel1(); break;
            case 2: map = LevelLoader.loadLevel2(); break;
            case 3: map = LevelLoader.loadLevel3(); break;
            case 4: map = LevelLoader.loadLevel4(); break;
            default: showFinalVictoryScreen(); return;
        }
        gameView = new GameView(map);
        gameHUD = new GameHUD(map);
        root.setCenter(gameView);
        root.setRight(gameHUD);
        gameHUD.update();
        
        // Ensure focus returns to the game view after loading
        Platform.runLater(() -> { gameView.requestFocus(); root.requestFocus(); });
    }

    /**
     * Updates the logic for enemy entities in the game.
     * Specifically handles the movement for "AngryTeethTile" enemies present in Level 3.
     */
    private void updateEnemies() {
        if (currentLevel == 3) {
            // Reset movement flags for all enemies
            for (int y = 0; y < map.getHeight(); y++) {
                for (int x = 0; x < map.getWidth(); x++) {
                    Tile tile = map.getTileAt(x, y);
                    if (tile instanceof AngryTeethTile) ((AngryTeethTile) tile).hasMoved = false;
                }
            }
            // Execute movement logic for enemies
            for (int y = 0; y < map.getHeight(); y++) {
                for (int x = 0; x < map.getWidth(); x++) {
                    Tile tile = map.getTileAt(x, y);
                    if (tile instanceof AngryTeethTile) {
                        AngryTeethTile enemy = (AngryTeethTile) tile;
                        enemy.enemyMovement(map);
                        // Check for collision with the player immediately after enemy moves
                        if (enemy.getPosition().equals(map.getChip().getPosition())) map.getChip().takeDmg(1);
                    }
                }
            }
        }
        checkPlayerDamage();
    }

    /**
     * Verifies if the player is currently standing on a lethal tile (Fire, Water, Monster).
     * If the player is dead, it triggers the Game Over sequence.
     */
    private void checkPlayerDamage() {
        if (!gameRunning) return;
        Chip chip = map.getChip();
        Tile t = map.getTileAt(chip.getPosition().getX(), chip.getPosition().getY());
        
        // Instant damage from monsters
        if (t instanceof AngryTeethTile) chip.takeDmg(1);
        
        // Check life status
        if (!chip.isAlive()) handleGameOver(determineDeathCause(t));
    }

    /**
     * Checks if the player has met the conditions to complete the level.
     * If the level is complete, it advances to the next level or shows the victory screen.
     */
    private void checkGameStatus() {
        if (!gameRunning) return;
        if (!map.getChip().isAlive()) {
            checkPlayerDamage(); return;
        }
        // Check if the player stepped on the Exit tile
        if (map.takeNextLevelRequest()) {
            if (currentLevel < TOTAL_LEVELS) showLevelCompleteScreen();
            else showFinalVictoryScreen();
        }
    }

    /**
     * Determines the appropriate "Game Over" message based on the tile that killed the player.
     * @param t The tile the player is currently standing on.
     * @return A string describing the cause of death.
     */
    private String determineDeathCause(Tile t) {
        if (t instanceof FireTile) return "You burned to death!";
        if (t instanceof WaterTile) return "You drowned!";
        return "You were eaten by a monster!";
    }

    /**
     * Displays a custom, retro-styled modal dialog box.
     * This is used for Pause menus, Game Over screens, and Level Completion screens.
     * @param title   The text to display in the window header.
     * @param message The main message body of the dialog.
     * @param buttons An array of strings representing the button labels.
     * @param actions An array of Runnable actions corresponding to each button.
     */
    private void showRetroDialog(String title, String message, String[] buttons, Runnable[] actions) {
        gameRunning = false; // Pause the game loop logic
        Platform.runLater(() -> {
            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.initOwner(primaryStage);
            dialog.initStyle(StageStyle.UNDECORATED); // Remove OS window borders
            
            // Build Custom Header
            HBox header = new HBox();
            header.setAlignment(Pos.CENTER_LEFT);
            header.setPadding(new Insets(4, 8, 4, 8));
            header.setStyle("-fx-background-color: #FF8000; -fx-border-color: white grey grey white; -fx-border-width: 2;");
            
            Label titleLbl = new Label(title);
            titleLbl.setFont(Font.font("Arial", FontWeight.BOLD, 12));
            titleLbl.setTextFill(javafx.scene.paint.Color.BLACK);
            
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            
            // Custom Close Button
            Button closeX = new Button("X");
            closeX.setStyle("-fx-background-color: #C0C0C0; -fx-font-weight: bold; -fx-font-size: 10; -fx-border-color: white grey grey white; -fx-border-width: 1;");
            closeX.setOnAction(e -> {
                dialog.close();
                if (title.equals("Game Over") || title.equals("Winner!")) primaryStage.close(); 
                else gameRunning = true; 
            });
            header.getChildren().addAll(titleLbl, spacer, closeX);
            
            // Build Body
            VBox body = new VBox(15);
            body.setAlignment(Pos.CENTER);
            body.setPadding(new Insets(20));
            body.setStyle("-fx-background-color: #C0C0C0; -fx-border-color: white grey grey white; -fx-border-width: 2;");
            
            Label msgLbl = new Label(message);
            msgLbl.setFont(Font.font("Arial", FontWeight.BOLD, 16));
            msgLbl.setTextAlignment(TextAlignment.CENTER);
            
            // Build Stats Box
            VBox statsBox = new VBox(5);
            statsBox.setAlignment(Pos.CENTER);
            statsBox.setStyle("-fx-border-color: grey; -fx-padding: 10;"); 
            if (map != null) {
                statsBox.getChildren().addAll(
                    createStatLabel("Current Level:  " + currentLevel),
                    createStatLabel("Chips Collected: " + map.getChipsCollected() + " / " + map.getChipsRequired()),
                    createStatLabel("Lives Remaining: " + (map.getChip() != null ? map.getChip().getHealth() : 0))
                );
            }
            
            // Build Dynamic Buttons
            HBox buttonBox = new HBox(10);
            buttonBox.setAlignment(Pos.CENTER);
            for (int i = 0; i < buttons.length; i++) {
                Button btn = new Button(buttons[i]);
                btn.setPrefWidth(120);
                btn.setStyle("-fx-background-color: #C0C0C0; -fx-border-color: white black black white; -fx-border-width: 2; -fx-font-weight: bold;");
                final int index = i;
                btn.setOnAction(e -> {
                    dialog.close();
                    if (actions[index] != null) actions[index].run();
                });
                buttonBox.getChildren().add(btn);
            }
            
            body.getChildren().addAll(msgLbl, statsBox, buttonBox);
            VBox windowLayout = new VBox(0);
            windowLayout.setStyle("-fx-border-color: black; -fx-border-width: 1;"); 
            windowLayout.getChildren().addAll(header, body);
            Scene dialogScene = new Scene(windowLayout);
            dialog.setScene(dialogScene);
            dialog.showAndWait();
        });
    }

    /**
     * Helper method to create a stylized label for the stats display.
     * @param text The text content for the label.
     * @return A styled Label object.
     */
    private Label createStatLabel(String text) {
        Label l = new Label(text);
        l.setFont(Font.font("Monospaced", FontWeight.BOLD, 12));
        return l;
    }

    /**
     * Pauses the game and opens the Pause Menu dialog.
     */
    private void showPauseMenu() {
        showRetroDialog("Game Paused", "Paused.", new String[]{"Resume", "Restart Level", "Exit Game"}, new Runnable[]{() -> { gameRunning = true; }, () -> { loadLevel(currentLevel); }, () -> { primaryStage.close(); }});
    }

    /**
     * Triggers the Game Over dialog with a specific cause of death.
     * @param cause The message describing how the player died.
     */
    private void handleGameOver(String cause) {
        showRetroDialog("Game Over", cause, new String[]{"Respawn", "Exit Game"}, new Runnable[]{() -> { loadLevel(currentLevel); }, () -> { primaryStage.close(); }});
    }

    /**
     * Triggers the Level Complete dialog when the player successfully finishes a level.
     */
    private void showLevelCompleteScreen() {
        showRetroDialog("Level Complete", "Level Cleared!", new String[]{"Next Level"}, new Runnable[]{() -> { loadLevel(currentLevel + 1); }});
    }

    /**
     * Triggers the Final Victory dialog when all levels are completed.
     */
    private void showFinalVictoryScreen() {
        showRetroDialog("Winner!", "Congratulations!", new String[]{"Exit Game"}, new Runnable[]{() -> { primaryStage.close(); }});
    }

    /**
     * Attempts to load and play the background music file.
     * If the file is not found, the exception is silently caught to prevent a crash.
     */
    private void playBackgroundMusic() {
        try {
            String musicPath = getClass().getResource("music.mp3").toExternalForm();
            Media sound = new Media(musicPath);
            mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE); 
            mediaPlayer.setVolume(0.5); 
            mediaPlayer.play();
        } catch (Exception e) {}
    }

    /**
     * The main entry point for the Java application.
     * @param args Command line arguments.
     */
    public static void main(String[] args) { launch(args); }
}