/**
 * Represents a Microchip collectible item.
 * This is the primary objective item in the game. The player must collect 
 * a specific number of these chips to pass the Chip Socket and reach the Exit 
 * to complete the level.
 */
public class Microchip extends ItemTile {

    /**
     * Constructs a new Microchip item at the specified coordinate.
     * Initializes the tile with the internal ID "microchip", the display name "Microchip",
     * and the visual asset key "chip".
     * @param position The (x, y) coordinate where this microchip is placed on the map.
     */
    public Microchip(Position position) {
        super(position, "microchip", "Microchip", "chip");
    }

    /**
     * Executed immediately when the player (Chip) enters the tile containing this item.
     * This handles the collection logic specific to Microchips:
     * 1. Updates the player's personal inventory count.
     * 2. Updates the global Map progress (checking if enough chips are found).
     * 3. Consumes the item by removing it from the grid.
     * @param map  The current instance of the game map, used to track level progress.
     * @param chip The player entity collecting the item.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // 1. Specific collection logic: Add to Player Inventory
        chip.getInventory().addMicrochip();

        // 2. Notify the Map to increment the global "Collected" counter.
        // This is crucial for determining if the Chip Socket can be opened.
        map.incrementChipsCollected();

        // 3. Remove the physical tile from the board so it disappears.
        // This effectively consumes the item.
        map.removeTile(this.getPosition()); 
    }
}