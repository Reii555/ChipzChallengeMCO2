/**
 * Represents a standard floor tile.
 * This is the basic terrain of the game that acts as a safe, walkable path for
 * the player (Chip) and enemies. It has no special effects or interactions.
 */
public class FloorTile extends Tile {

    /**
     * Creates a new Floor tile at the specified position.
     * @param position The grid coordinates for this floor tile.
     */
    public FloorTile(Position position) {
        super(position);
    }

    /**
     * Determines if the player can step onto this tile.
     * Always returns true, as the floor is the primary walkable surface.
     * @param c The Chip instance attempting to enter.
     * @return true, allowing the player to move here.
     */
    @Override
    public boolean isPassable(Chip c) {
        return true;
    }

    /**
     * Handles the logic when the player enters this tile.
     * For a standard floor, no specific game logic or state change occurs.
     * @param map  The current game map.
     * @param chip The player character.
     */
    @Override
    public void onEnter(Map map, Chip chip) {
        // No action needed; Chip simply occupies the tile.
    }

    // GUI Methods 

    /**
     * Returns the string identifier for this tile type.
     * Used by the GUI or saving mechanisms to identify the tile.
     * @return "FloorTile"
     */
    @Override
    public String getTileType(){
        return "FloorTile";
    }

    /**
     * Returns the visual state string for rendering logic.
     * @return "floor"
     */
    @Override
    public String getVisualState(){
        return "floor";
    }
}